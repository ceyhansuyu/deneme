-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Anamakine: localhost
-- Üretim Zamanı: 10 Nisan 2012 saat 19:33:40
-- Sunucu sürümü: 5.5.8
-- PHP Sürümü: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `forum`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayar`
--

CREATE TABLE IF NOT EXISTS `ayar` (
  `ayar_id` int(15) NOT NULL,
  `forum_durumu` varchar(20) NOT NULL,
  `copyright` varchar(1500) NOT NULL,
  `forum_kapali_sebep` varchar(255) NOT NULL,
  `script_yolu` varchar(100) NOT NULL,
  `flood_aralik` varchar(255) NOT NULL,
  `arama_flood_aralik` varchar(255) NOT NULL,
  `max_giris_deneme` varchar(100) NOT NULL,
  `giris_ceza_suresi` varchar(255) NOT NULL,
  `aktivasyon_yontemi` varchar(255) NOT NULL,
  `board_email` varchar(255) NOT NULL,
  `board_startdate` varchar(255) NOT NULL,
  `sistem_zaman_dilimi` varchar(100) NOT NULL,
  `zaman_formati` varchar(100) NOT NULL,
  `default_lang` varchar(255) NOT NULL,
  `default_style` varchar(255) NOT NULL,
  `ozel_mesaj` varchar(20) NOT NULL,
  `gelen_kutusu` varchar(100) NOT NULL,
  `ulasan_kutusu` varchar(100) NOT NULL,
  `kaydedilen_kutusu` varchar(100) NOT NULL,
  `server_name` varchar(255) NOT NULL,
  `sitename` varchar(255) NOT NULL,
  `site_desc` varchar(255) NOT NULL,
  `sayfala_limit_konu` varchar(20) NOT NULL,
  `sayfala_limit_cevap` varchar(20) NOT NULL,
  `uyelik_sozlesmesi` varchar(2000) NOT NULL,
  `onay_kodu` varchar(100) NOT NULL,
  `ekstra_spam_sorusu` varchar(100) NOT NULL,
  `kayit_sorusu` varchar(255) NOT NULL,
  `kayit_cevabi` varchar(255) NOT NULL,
  `admin_notu` varchar(2000) NOT NULL,
  `son_ayar_guncelleme` varchar(100) NOT NULL,
  `en_yeni_uye` varchar(300) NOT NULL,
  `en_yeni_uye_id` varchar(300) NOT NULL,
  `toplam_uye_sayisi` varchar(300) NOT NULL,
  PRIMARY KEY (`ayar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `ayar`
--

INSERT INTO `ayar` (`ayar_id`, `forum_durumu`, `copyright`, `forum_kapali_sebep`, `script_yolu`, `flood_aralik`, `arama_flood_aralik`, `max_giris_deneme`, `giris_ceza_suresi`, `aktivasyon_yontemi`, `board_email`, `board_startdate`, `sistem_zaman_dilimi`, `zaman_formati`, `default_lang`, `default_style`, `ozel_mesaj`, `gelen_kutusu`, `ulasan_kutusu`, `kaydedilen_kutusu`, `server_name`, `sitename`, `site_desc`, `sayfala_limit_konu`, `sayfala_limit_cevap`, `uyelik_sozlesmesi`, `onay_kodu`, `ekstra_spam_sorusu`, `kayit_sorusu`, `kayit_cevabi`, `admin_notu`, `son_ayar_guncelleme`, `en_yeni_uye`, `en_yeni_uye_id`, `toplam_uye_sayisi`) VALUES
(1, 'hayir', 'Copyright ©2012 Php Forum. SQL', 'forum su anda acik', '/forum/', '9', '8', '3', '50', 'kapali', 'teraw0rm@gmail.com', '5 cevap', '3', '|d M Y|, H:i', 'Türkçe', 'delta', 'kapali', '10 44', '10', '50', 'localhost', 'Site adý', 'Site description', '3', '3', '<p>\r\n	<span style="color:#ff0000;"><b style="font-weight: bold;">Foruma &uuml;ye olmak i&ccedil;in aþaðýdaki maddeleri kabul etmeniz gerekmektedir.</b></span></p>\r\n<ul>\r\n	<li>\r\n		<strong>Foruma <span style="display: none;">&nbsp;</span>yazdýðýnýz <span style="display: none;">&nbsp;</span>i&ccedil;eriðin sorumluluðu tamamen size aittir, yazdýðýnýz i&ccedil;erikten forum yazarý veya forum y&ouml;neticileri sorumlu tutulamaz.</strong><br />\r\n		&nbsp;</li>\r\n	<li>\r\n		Foruma mesaj attýðýnýzda, tarihiyle birlikte ip adresiniz (internetteki kimliðiniz) de kaydedilir.<br />\r\n		&nbsp;</li>\r\n	<li>\r\n		Forum y&ouml;neticileri uygunsuz bulduðu mesajlarý deðiþtirme ve/veya silme, &uuml;yeliðinizi iptal etme hakkýna sahiptir.<br />\r\n		&nbsp;</li>\r\n	<li>\r\n		Forumda yasalarý aykýrý her t&uuml;rl&uuml; yazý yazýlmasý kesinlikle yasaktýr.<br />\r\n		&nbsp;</li>\r\n	<li>\r\n		Kopya yazýlým, kopya m&uuml;zik, hack, crack, warez gibi dosyalarýn veya i&ccedil;eriðin yazýlmasý yasaktýr.<br />\r\n		&nbsp;</li>\r\n	<li>\r\n		M&uuml;stehcen, kaba, iftira niteliðinde, tehdit edici yazýlar yazýlmasý yasaktýr.<br />\r\n		&nbsp;</li>\r\n	<li>\r\n		Foruma yazdýðýnýz yazýlarýn y&uuml;z binlerce kiþi tarafýndan okunabileceðini d&uuml;þ&uuml;nerek; T&uuml;rk&ccedil;emize yakýþan, imla kurallarýna uygun g&uuml;zel bir dille yazýn.<br />\r\n		&nbsp;</li>\r\n	<li>\r\n		Yukarýdaki maddelerin deðiþtirilme hakký saklýdýr.</li>\r\n</ul>\r\n<p>\r\n	<span id="cke_bm_49S" style="display: none;">&nbsp;</span><span style="color:#a52a2a;"><strong><s>window.location.href =&quot;deneme&quot;</s></strong></span><span id="cke_bm_49E" style="display: none;">&nbsp;</span></p>\r\n', 'hayir', 'hayir', 'nasilsin?', 'iyi', 'Ak&#305;ll&#305; olun akl&#305;n&#305;z&#305; al&#305;r&#305;m haa !!!  yalan dünya rrrrrrrrrrrr\r\n\r\nbugün y&#305;k&#305;&#287;&#305;m ulan biliyor musun fdsfds', '1324891905', 'petaw0rm', '29', '6');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `forumlar`
--

CREATE TABLE IF NOT EXISTS `forumlar` (
  `forum_id` int(10) NOT NULL AUTO_INCREMENT,
  `kat_id` varchar(255) NOT NULL,
  `forum_tipi` varchar(300) NOT NULL,
  `forum_adi` varchar(255) NOT NULL,
  `forum_tarifi` varchar(255) NOT NULL,
  `forum_son_mesaj_title` varchar(200) NOT NULL,
  `forum_son_mesaj_id` varchar(300) NOT NULL,
  `forum_son_mesaj_konu_id` varchar(200) NOT NULL,
  `forum_son_mesaj_kul` varchar(300) NOT NULL,
  `forum_son_mesaj_kul_id` varchar(300) NOT NULL,
  `forum_son_mesaj_zamani` varchar(300) NOT NULL,
  `forum_toplam_konu` varchar(300) NOT NULL,
  `forum_toplam_mesaj` varchar(300) NOT NULL,
  `sirala` varchar(50) NOT NULL,
  PRIMARY KEY (`forum_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Tablo döküm verisi `forumlar`
--

INSERT INTO `forumlar` (`forum_id`, `kat_id`, `forum_tipi`, `forum_adi`, `forum_tarifi`, `forum_son_mesaj_title`, `forum_son_mesaj_id`, `forum_son_mesaj_konu_id`, `forum_son_mesaj_kul`, `forum_son_mesaj_kul_id`, `forum_son_mesaj_zamani`, `forum_toplam_konu`, `forum_toplam_mesaj`, `sirala`) VALUES
(1, '1', '', 'Ýlk Forumum', 'Ýlk forumumn tarifi    ', '', '', '', '', '', '', '', '', '1'),
(2, '2', '', 'Ýkinci forumum', 'Ýkinci forumum tarifi', 'Re: Talihim yok bahtým kara', '7', '1', 'admin', '18', '1334031849', '3', '3', '2');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kategoriler`
--

CREATE TABLE IF NOT EXISTS `kategoriler` (
  `kat_id` int(50) NOT NULL AUTO_INCREMENT,
  `kat_title` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `kat_desc` varchar(255) CHARACTER SET latin1 NOT NULL,
  `sirala` int(50) NOT NULL,
  PRIMARY KEY (`kat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin5 AUTO_INCREMENT=3 ;

--
-- Tablo döküm verisi `kategoriler`
--

INSERT INTO `kategoriler` (`kat_id`, `kat_title`, `kat_desc`, `sirala`) VALUES
(1, 'Ýlk kategorim 5566', ' ilk kategorinin açýklamasý    66    ', 10),
(2, 'Ýkinci kategorim077', '   777777777                    ', 15);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `konular`
--

CREATE TABLE IF NOT EXISTS `konular` (
  `konu_id` int(50) NOT NULL AUTO_INCREMENT,
  `konu_forum_id` varchar(50) NOT NULL,
  `konu_mod` varchar(255) NOT NULL,
  `konu_baslik` varchar(1000) NOT NULL,
  `konu_goruntulenme` varchar(20) NOT NULL,
  `konu_cevap_sayisi` varchar(20) NOT NULL DEFAULT '0',
  `konu_zamani` varchar(255) NOT NULL,
  `konu_author` varchar(255) NOT NULL,
  `konu_author_id` varchar(100) NOT NULL,
  `konu_author_ip` varchar(100) NOT NULL,
  `konu_ikonu` varchar(200) NOT NULL,
  `son_mesaj_id` varchar(50) NOT NULL,
  `son_mesaj_zamani` varchar(200) NOT NULL,
  `son_mesaj_yazar` varchar(300) NOT NULL,
  `son_mesaj_yazar_id` varchar(300) NOT NULL,
  PRIMARY KEY (`konu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Tablo döküm verisi `konular`
--

INSERT INTO `konular` (`konu_id`, `konu_forum_id`, `konu_mod`, `konu_baslik`, `konu_goruntulenme`, `konu_cevap_sayisi`, `konu_zamani`, `konu_author`, `konu_author_id`, `konu_author_ip`, `konu_ikonu`, `son_mesaj_id`, `son_mesaj_zamani`, `son_mesaj_yazar`, `son_mesaj_yazar_id`) VALUES
(1, '2', 'normal', 'Talihim yok bahtým kara', '66', '3', '1334031640', 'teraw0rm', '', '127.0.0.1', 'yok', '7', '1334031849', 'admin', '18'),
(2, '2', 'normal', '100 bin dolar ile bu hale geldi', '3', '0', '1334031669', 'teraw0rm', '', '127.0.0.1', 'yok', '', '1334031669', 'teraw0rm', '1'),
(3, '2', 'normal', 'General Mobile Planet modelini çýkardý', '3', '0', '1334031749', 'admin', '', '127.0.0.1', 'yok', '', '1334031749', 'admin', '18');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

CREATE TABLE IF NOT EXISTS `kullanicilar` (
  `kul_id` int(100) NOT NULL AUTO_INCREMENT,
  `kul_adi` varchar(255) NOT NULL,
  `kul_sifre` varchar(255) NOT NULL,
  `kul_hatirla_hash` varchar(300) NOT NULL,
  `kul_yetki` varchar(100) NOT NULL,
  `kul_email` varchar(255) NOT NULL,
  `kul_dogum_tarihi` varchar(50) NOT NULL,
  `kul_imza` varchar(400) NOT NULL,
  `kul_kayit_zamani` varchar(255) NOT NULL,
  `kul_tarih_modu` varchar(100) NOT NULL,
  `kul_son_harekat` varchar(40) NOT NULL,
  `kul_son_giris` varchar(255) NOT NULL,
  `kul_son_cikis` varchar(255) NOT NULL DEFAULT '0',
  `kul_tema` varchar(255) NOT NULL,
  `kul_hangi_sayfada` varchar(100) NOT NULL,
  `kul_son_aktivite_zamani` varchar(100) NOT NULL,
  PRIMARY KEY (`kul_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Tablo döküm verisi `kullanicilar`
--

INSERT INTO `kullanicilar` (`kul_id`, `kul_adi`, `kul_sifre`, `kul_hatirla_hash`, `kul_yetki`, `kul_email`, `kul_dogum_tarihi`, `kul_imza`, `kul_kayit_zamani`, `kul_tarih_modu`, `kul_son_harekat`, `kul_son_giris`, `kul_son_cikis`, `kul_tema`, `kul_hangi_sayfada`, `kul_son_aktivite_zamani`) VALUES
(1, 'teraw0rm', 'f7703da5a7f255cf3d4db062f13defb5e18a08cc', 'H_5[n$}9*pKLs8r4K1wrf2YlwAn#Eb1334074333', '', 'ceyhansuyu@gmail.com', '15.09.1986', 'aha bu benim imzamdýr iþte', 'bugun', '3', '1315139509', '1334074333', '1324722994', 'bos deðil ', '', ''),
(18, 'admin', 'f7703da5a7f255cf3d4db062f13defb5e18a08cc', '9wWL5x7D?wfN0?2W!GhO93DOa$dS@A1334076842', '', 'teraworm@gmail.com', '15.09.1985', 'aha bu benim imzamd?r i?te', '1312560213', '3', '1315050791', '1334076842', '1324732650', '', '', ''),
(19, 'trojen', 'f7703da5a7f255cf3d4db062f13defb5e18a08cc', '', '', 'tro@tro.com', '15.09.1986', 'trojen in imzasý', '1314287938', '3', '1315142085', '1315139493', '', 'bos deðil', '', ''),
(21, 'ferrari', '39dfa55283318d31afe5a3ff4a0e3253e2045e43', '(dXngG@7PM)c-@GY$()pC+0-@DRDyI1334077118', '0', 'ferrari@ferrari.com', '', '', '1333932966', '', '', '1334077119', '0', '', '', ''),
(28, 'tufan kursat', 'f7703da5a7f255cf3d4db062f13defb5e18a08cc', '(nbsXP8}I*j5BTq@2WG}w$OnU-Bdq]1334085921', '0', 'tufan@kursat.com', '', '', '1334084681', '', '', '1334085921', '0', '', '', ''),
(29, 'petaw0rm', 'f7703da5a7f255cf3d4db062f13defb5e18a08cc', '', '0', 'petaw0rm@petaw0rm.com', '', '', '1334085752', '', '', '', '0', '', '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mesajlar`
--

CREATE TABLE IF NOT EXISTS `mesajlar` (
  `mesaj_id` int(50) NOT NULL AUTO_INCREMENT,
  `mesaj_konu_id` varchar(20) NOT NULL,
  `mesaj_zamani` varchar(100) NOT NULL,
  `mesaj_author` varchar(100) NOT NULL,
  `mesaj_author_id` varchar(100) NOT NULL,
  `mesaj_author_ip` varchar(100) NOT NULL,
  `mesaj_baslik` varchar(255) NOT NULL,
  `mesaj_govde` varchar(5000) NOT NULL,
  `mesaj_ikonu` varchar(200) NOT NULL,
  PRIMARY KEY (`mesaj_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Tablo döküm verisi `mesajlar`
--

INSERT INTO `mesajlar` (`mesaj_id`, `mesaj_konu_id`, `mesaj_zamani`, `mesaj_author`, `mesaj_author_id`, `mesaj_author_ip`, `mesaj_baslik`, `mesaj_govde`, `mesaj_ikonu`) VALUES
(1, '1', '1334031474', 'teraw0rm', '0', '127.0.0.1', 'Talihim yok bahtým kara', '<p>\r\n	eeeeeeeeeeeeeeeeeeeee</p>\r\n', ''),
(3, '2', '1334031669', 'teraw0rm', '0', '127.0.0.1', '100 bin dolar ile bu hale geldi', '<p>\r\n	trtrtr</p>\r\n', ''),
(4, '1', '1334031697', 'teraw0rm', '1', '127.0.0.1', 'Re: Talihim yok bahtým kara', '<p>\r\n	trtrtrtrt</p>\r\n', ''),
(5, '1', '1334031726', 'admin', '18', '127.0.0.1', 'Re: Talihim yok bahtým kara', '<p>\r\n	ewew ewew ewew</p>\r\n', ''),
(6, '3', '1334031749', 'admin', '0', '127.0.0.1', 'General Mobile Planet modelini çýkardý', '<p>\r\n	rererere</p>\r\n', ''),
(7, '1', '1334031849', 'admin', '18', '127.0.0.1', 'Re: Talihim yok bahtým kara', '<p>\r\n	reerwr ewr ewrewre</p>\r\n', '');
