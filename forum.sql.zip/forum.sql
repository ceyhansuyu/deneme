-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Anamakine: localhost
-- Üretim Zamanı: 20 Kasım 2012 saat 21:59:54
-- Sunucu sürümü: 5.5.8
-- PHP Sürümü: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `forum`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `abonelikler`
--

CREATE TABLE IF NOT EXISTS `abonelikler` (
  `abonelikID` int(100) NOT NULL AUTO_INCREMENT,
  `konuID` varchar(255) NOT NULL,
  `forumID` varchar(255) NOT NULL,
  `kullaniciID` varchar(255) NOT NULL,
  `abone_olunan_tarih` varchar(255) NOT NULL,
  PRIMARY KEY (`abonelikID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Tablo döküm verisi `abonelikler`
--

INSERT INTO `abonelikler` (`abonelikID`, `konuID`, `forumID`, `kullaniciID`, `abone_olunan_tarih`) VALUES
(7, '', '1', '18', '1347325031'),
(10, '16', '', '18', '1347339224'),
(12, '1', '', '18', '1347342372'),
(13, '14', '', '18', '1347342407'),
(14, '12', '', '18', '1347343159'),
(15, '', '5', '18', '1347347880'),
(16, '7', '', '19', '1349046401'),
(17, '26', '', '18', '1349046657'),
(18, '', '4', '18', '1349792826');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `anket_option`
--

CREATE TABLE IF NOT EXISTS `anket_option` (
  `anket_id` int(100) NOT NULL AUTO_INCREMENT,
  `anket_konu_id` varchar(100) NOT NULL,
  `anket_kat_id` varchar(500) NOT NULL,
  `anket_forum_id` varchar(500) NOT NULL,
  `anket_sorusu` varchar(255) NOT NULL,
  `anket_zamani` varchar(255) NOT NULL DEFAULT '0',
  `anket_secenekleri` text NOT NULL,
  `anket_oylari_toplam` text NOT NULL,
  `anket_secenekleri_sayisi` varchar(255) NOT NULL,
  `anket_bitis_suresi` varchar(255) NOT NULL,
  `anket_oy_degistir` varchar(255) NOT NULL,
  `anketi_oylayan_kul_sayisi` varchar(255) NOT NULL,
  `anket_public` varchar(255) NOT NULL,
  `anket_son_oy_zamani` varchar(255) NOT NULL,
  PRIMARY KEY (`anket_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Tablo döküm verisi `anket_option`
--

INSERT INTO `anket_option` (`anket_id`, `anket_konu_id`, `anket_kat_id`, `anket_forum_id`, `anket_sorusu`, `anket_zamani`, `anket_secenekleri`, `anket_oylari_toplam`, `anket_secenekleri_sayisi`, `anket_bitis_suresi`, `anket_oy_degistir`, `anketi_oylayan_kul_sayisi`, `anket_public`, `anket_son_oy_zamani`) VALUES
(6, '21', '', '', 'Uðurlu sayýnýz', '1347220146', '1|||2', '3|||1', '2', '', '', '4', '', '1347255056'),
(8, '32', '1', '2', 'Hangi takýmý tutyorsun', '1349786215', 'Fenerbahçe|||Galatasaray|||Beþiktaþ|||Trabzonspor', '1|||0|||0|||0', '4', '', 'oy_degistir', '1', '', '1349786479'),
(9, '33', '2', '4', 'Nasýlsýn', '1353431693', 'Ýyi|||kötü', '1|||0', '2', '1354233600', 'oy_degistir', '1', '', '1353431703');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `anket_oylar`
--

CREATE TABLE IF NOT EXISTS `anket_oylar` (
  `anket_oy_id` int(255) NOT NULL AUTO_INCREMENT,
  `anket_id` varchar(255) NOT NULL,
  `anket_kat_id` varchar(255) NOT NULL,
  `anket_forum_id` varchar(255) NOT NULL,
  `anket_konu_id` varchar(255) NOT NULL,
  `oyveren_kul_id` varchar(255) NOT NULL,
  `oy_zamani` varchar(255) NOT NULL,
  `oy_hangi_keyde` varchar(255) NOT NULL,
  `oy_tipi` varchar(100) NOT NULL,
  `oyveren_kul_ip` varchar(255) NOT NULL,
  PRIMARY KEY (`anket_oy_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Tablo döküm verisi `anket_oylar`
--

INSERT INTO `anket_oylar` (`anket_oy_id`, `anket_id`, `anket_kat_id`, `anket_forum_id`, `anket_konu_id`, `oyveren_kul_id`, `oy_zamani`, `oy_hangi_keyde`, `oy_tipi`, `oyveren_kul_ip`) VALUES
(9, '6', '', '', '', '18', '1347220149', '1', '0', '127.0.0.1'),
(10, '6', '', '', '', '19', '1347220731', '0', '0', '127.0.0.1'),
(11, '6', '', '', '', '21', '1347255027', '0', '0', '127.0.0.1'),
(12, '6', '', '', '', '32', '1347255056', '0', '0', '127.0.0.1'),
(14, '8', '1', '2', '32', '18', '1349786479', '0', '0', '127.0.0.1'),
(15, '9', '2', '4', '33', '18', '1353431703', '0', '0', '127.0.0.1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayar`
--

CREATE TABLE IF NOT EXISTS `ayar` (
  `ayar_id` int(15) NOT NULL,
  `forum_durumu` varchar(20) NOT NULL,
  `copyright` varchar(1500) NOT NULL,
  `forum_kapali_sebep` varchar(255) NOT NULL,
  `script_yolu` varchar(100) NOT NULL,
  `cookie_on_ek` varchar(500) NOT NULL,
  `anket_sayisi` varchar(255) NOT NULL,
  `cevrimici_zaman_asimi` varchar(255) NOT NULL,
  `cookie_zamani` varchar(500) NOT NULL,
  `flood_aralik` varchar(255) NOT NULL,
  `arama_flood_aralik` varchar(255) NOT NULL,
  `max_giris_deneme` varchar(100) NOT NULL,
  `giris_ceza_suresi` varchar(255) NOT NULL,
  `aktivasyon_yontemi` varchar(255) NOT NULL,
  `board_email` varchar(255) NOT NULL,
  `board_startdate` varchar(255) NOT NULL,
  `sistem_zaman_dilimi` varchar(100) NOT NULL,
  `zaman_formati` varchar(100) NOT NULL,
  `default_lang` varchar(255) NOT NULL,
  `default_style` varchar(255) NOT NULL,
  `ozel_mesaj` varchar(20) NOT NULL,
  `gelen_kutusu` varchar(100) NOT NULL,
  `ulasan_kutusu` varchar(100) NOT NULL,
  `kaydedilen_kutusu` varchar(100) NOT NULL,
  `ozel_mesaj_limiti` varchar(255) NOT NULL,
  `server_name` varchar(255) NOT NULL,
  `sitename` varchar(255) NOT NULL,
  `site_desc` varchar(255) NOT NULL,
  `sayfala_limit_konu` varchar(20) NOT NULL,
  `sayfala_limit_cevap` varchar(20) NOT NULL,
  `sicak_konu_limit` varchar(100) NOT NULL,
  `uyelik_sozlesmesi` varchar(2000) NOT NULL,
  `onay_kodu` varchar(100) NOT NULL,
  `ekstra_spam_sorusu` varchar(100) NOT NULL,
  `kayit_sorusu` varchar(255) NOT NULL,
  `kayit_cevabi` varchar(255) NOT NULL,
  `reCAPTCHA_aktif_mi` varchar(250) NOT NULL,
  `reCAPTCHA_publickey` varchar(250) NOT NULL,
  `reCAPTCHA_privatekey` varchar(250) NOT NULL,
  `admin_notu` varchar(2000) NOT NULL,
  `son_ayar_guncelleme` varchar(100) NOT NULL,
  `en_yeni_uye` varchar(300) NOT NULL,
  `en_yeni_uye_id` varchar(300) NOT NULL,
  `toplam_uye_sayisi` varchar(300) NOT NULL,
  `online_rekor_kisi` varchar(255) NOT NULL,
  `online_rekor_misafir` varchar(255) NOT NULL,
  `online_rekor_tarih` varchar(255) NOT NULL,
  `seo_durum` varchar(100) NOT NULL,
  PRIMARY KEY (`ayar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `ayar`
--

INSERT INTO `ayar` (`ayar_id`, `forum_durumu`, `copyright`, `forum_kapali_sebep`, `script_yolu`, `cookie_on_ek`, `anket_sayisi`, `cevrimici_zaman_asimi`, `cookie_zamani`, `flood_aralik`, `arama_flood_aralik`, `max_giris_deneme`, `giris_ceza_suresi`, `aktivasyon_yontemi`, `board_email`, `board_startdate`, `sistem_zaman_dilimi`, `zaman_formati`, `default_lang`, `default_style`, `ozel_mesaj`, `gelen_kutusu`, `ulasan_kutusu`, `kaydedilen_kutusu`, `ozel_mesaj_limiti`, `server_name`, `sitename`, `site_desc`, `sayfala_limit_konu`, `sayfala_limit_cevap`, `sicak_konu_limit`, `uyelik_sozlesmesi`, `onay_kodu`, `ekstra_spam_sorusu`, `kayit_sorusu`, `kayit_cevabi`, `reCAPTCHA_aktif_mi`, `reCAPTCHA_publickey`, `reCAPTCHA_privatekey`, `admin_notu`, `son_ayar_guncelleme`, `en_yeni_uye`, `en_yeni_uye_id`, `toplam_uye_sayisi`, `online_rekor_kisi`, `online_rekor_misafir`, `online_rekor_tarih`, `seo_durum`) VALUES
(1, 'acik', 'Copyright ©2012 Php Forum. SQL (Bir Ceyhansuyu Projesi)', 'Forum bakým nedeniyle þu anda hizmet veremiyor.\r\n<br>Anlayýþýnýz için teþekkür ederiz.', '/deneme/', 'f_', '20', '300', '2500000', '9', '10', '3', '50', 'kapali', 'teraw0rm@gmail.com', '5 ', '3', '|d M Y|, H:i', 'Türkçe', 'forum', 'kapali', '10', '10', '50', '10', 'localhost', 'Site adý', 'Site description', '6', '6', '6', '<span style="color: #ff0000;"><strong style="font-weight: bold;">Foruma &uuml;ye olmak i&ccedil;in aþaðýdaki maddeleri kabul etmeniz gerekmektedir.</strong></span>\r\n<ul>\r\n<li><strong>Foruma <span style="display: none;">&nbsp;</span>yazdýðýnýz <span style="display: none;">&nbsp;</span>i&ccedil;eriðin sorumluluðu tamamen size aittir, yazdýðýnýz i&ccedil;erikten forum yazarý veya forum y&ouml;neticileri sorumlu tutulamaz.</strong><br /> &nbsp;</li>\r\n<li>Foruma mesaj attýðýnýzda, tarihiyle birlikte ip adresiniz (internetteki kimliðiniz) de kaydedilir.<br /> &nbsp;</li>\r\n<li>Forum y&ouml;neticileri uygunsuz bulduðu mesajlarý deðiþtirme ve/veya silme, &uuml;yeliðinizi iptal etme hakkýna sahiptir.<br /> &nbsp;</li>\r\n<li>Forumda yasalarý aykýrý her t&uuml;rl&uuml; yazý yazýlmasý kesinlikle yasaktýr.<br /> &nbsp;</li>\r\n<li>Kopya yazýlým, kopya m&uuml;zik, hack, crack, warez gibi dosyalarýn veya i&ccedil;eriðin yazýlmasý yasaktýr.<br /> &nbsp;</li>\r\n<li>M&uuml;stehcen, kaba, iftira niteliðinde, tehdit edici yazýlar yazýlmasý yasaktýr.<br /> &nbsp;</li>\r\n<li>Foruma yazdýðýnýz yazýlarýn y&uuml;z binlerce kiþi tarafýndan okunabileceðini d&uuml;þ&uuml;nerek; T&uuml;rk&ccedil;emize yakýþan, imla kurallarýna uygun g&uuml;zel bir dille yazýn.<br /> &nbsp;</li>\r\n<li>Yukarýdaki maddelerin deðiþtirilme hakký saklýdýr.</li>\r\n</ul>', 'hayir', 'acik', 'Türkiye''mizin en kalabalýk þehri neresidir?', 'istanbul', 'acik', '6LexM8gSAAAAAJUBSIIZ3Z5RuuW96OgIEpw0o4gf', '6LexM8gSAAAAAJcmVQ9UZRUlnQCwNHHu2D8atYYE', 'Akýllý olun aklýnýzý alýrým haa !!!  yalan dünya rrrrrrrrrrrr\r\n\r\nbugün yýkýðým ulan biliyor musun \r\n\r\nne bileyim lan', '1353448757', 'gix', '34', '11', '4', '0', '1347283908', 'kapali');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `forumlar`
--

CREATE TABLE IF NOT EXISTS `forumlar` (
  `forum_id` int(10) NOT NULL AUTO_INCREMENT,
  `kat_id` varchar(255) NOT NULL,
  `forum_tipi` varchar(300) NOT NULL,
  `forum_ust_f` varchar(200) NOT NULL,
  `forum_ust_title` varchar(500) NOT NULL,
  `forum_adi` varchar(255) NOT NULL,
  `forum_tarifi` varchar(255) NOT NULL,
  `forum_son_mesaj_title` varchar(200) NOT NULL,
  `forum_son_mesaj_id` varchar(300) NOT NULL,
  `forum_son_mesaj_konu_id` varchar(200) NOT NULL,
  `forum_son_mesaj_kul` varchar(300) NOT NULL,
  `forum_son_mesaj_kul_id` varchar(300) NOT NULL,
  `forum_son_mesaj_zamani` varchar(300) NOT NULL,
  `forum_son_mesaj_ikonu` varchar(255) NOT NULL,
  `forum_toplam_konu` varchar(300) NOT NULL,
  `forum_toplam_mesaj` varchar(300) NOT NULL,
  `forum_kilitlimi` varchar(100) NOT NULL,
  `forum_link_mi` varchar(255) NOT NULL,
  `forum_link_adi` varchar(255) NOT NULL,
  `forum_link_aciklama` varchar(255) NOT NULL,
  `forum_link_url` varchar(500) NOT NULL,
  `forum_link_sayac` varchar(255) NOT NULL,
  `forum_resmi` varchar(500) NOT NULL,
  `sirala` varchar(50) NOT NULL,
  PRIMARY KEY (`forum_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Tablo döküm verisi `forumlar`
--

INSERT INTO `forumlar` (`forum_id`, `kat_id`, `forum_tipi`, `forum_ust_f`, `forum_ust_title`, `forum_adi`, `forum_tarifi`, `forum_son_mesaj_title`, `forum_son_mesaj_id`, `forum_son_mesaj_konu_id`, `forum_son_mesaj_kul`, `forum_son_mesaj_kul_id`, `forum_son_mesaj_zamani`, `forum_son_mesaj_ikonu`, `forum_toplam_konu`, `forum_toplam_mesaj`, `forum_kilitlimi`, `forum_link_mi`, `forum_link_adi`, `forum_link_aciklama`, `forum_link_url`, `forum_link_sayac`, `forum_resmi`, `sirala`) VALUES
(1, '1', '', '', '', 'Ýlk Forumum', 'Ýlk forumumn tarifi    ', 'Re: rewrewrewrewrew', '157', '29', 'admin', '18', '1349789691', 'resim/icons/icon1.gif', '14', '31', 'evet', 'hayir', '', '', '', '', '', '1'),
(2, '1', '', '', '', 'ikinci forum', 'ikinci forumun tarifi', 'Re: Bu güzel olacak', '155', '32', 'admin', '18', '1349786184', 'resim/icons/icon12.gif', '8', '41', 'hayir', 'hayir', '', '', '', '', '', '0'),
(3, '1', 'alt', '1', 'Ýlk Forumum', 'ilk alt forum', 'ilk alt forum tarif', 'TROJENDEN SELAM', '141', '26', 'trojen', '19', '1349046614', 'resim/icons/icon1.gif', '5', '3', 'hayir', 'hayir', '', '', '', '', '', '3'),
(4, '2', '', '', '', 'ikinci kategori ilk forum', 'ikinci kategori ilk forum tarifi', 'Re: Sabit konu olacak', '160', '33', 'admin', '18', '1353439670', 'resim/icons/icon3.gif', '7', '29', 'hayir', 'hayir', '', '', '', '21', '', '9'),
(5, '2', '', '', '', 'Kat2 2.forum ilk forum', 'Kat2 2.forum tarifi', 'Anket', '147', '27', 'admin', '18', '1349213729', 'resim/icons/icon1.gif', '3', '4', 'hayir', 'hayir', '', '', '', '', '', '8'),
(6, '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'evet', 'Deneme Link', 'Deneme link aciklama', 'http://localhost', '118', '', '7'),
(7, '1', 'alt', '1', '', 'rewrewr', 'ewrewrewrew', '', '', '', '', '', '', '', '', '', '', 'hayir', '', '', '', '', '', ''),
(8, '3', '', '', '', 'wwwwwwwwwwwww', 'wwwwwwwwwwwwwww', 'Re: rerer er', '161', '34', 'admin', '18', '1353448398', 'resim/icons/icon11.gif', '1', '1', '', 'hayir', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ihbar`
--

CREATE TABLE IF NOT EXISTS `ihbar` (
  `ihbarID` int(100) NOT NULL AUTO_INCREMENT,
  `bildirenID` varchar(250) NOT NULL,
  `bildiren` varchar(255) NOT NULL,
  `bildiriBaslik` varchar(255) NOT NULL,
  `bildiri` varchar(1000) NOT NULL,
  `bildirenIP` varchar(100) NOT NULL,
  `bildirilenAdres` varchar(1000) NOT NULL,
  PRIMARY KEY (`ihbarID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Tablo döküm verisi `ihbar`
--

INSERT INTO `ihbar` (`ihbarID`, `bildirenID`, `bildiren`, `bildiriBaslik`, `bildiri`, `bildirenIP`, `bildirilenAdres`) VALUES
(1, '18', 'admin', 'Bu ne biçim mesajdýr be', 'aynen öyledir ya', '127.0.0.1', 'showthread.php?t=9#mesaj144'),
(2, '18', 'admin', '', '', '127.0.0.1', 'showthread.php?t=9#mesaj146'),
(3, '18', 'admin', '', '', '127.0.0.1', 'showthread.php?t=9#mesaj146'),
(4, '18', 'admin', '', '', '127.0.0.1', 'showthread.php?t=9&sayfa=2#mesaj146'),
(5, '18', 'admin', '', '', '127.0.0.1', 'showthread.php?t=26&sayfa=1#mesaj141'),
(6, '18', 'admin', '', '', '127.0.0.1', 'showthread.php?t=24&sayfa=1#mesaj129'),
(7, '18', 'admin', 'rewr', 'wrewrewrew', '127.0.0.1', 'showthread.php?t=23&sayfa=1#mesaj121');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kategoriler`
--

CREATE TABLE IF NOT EXISTS `kategoriler` (
  `kat_id` int(50) NOT NULL AUTO_INCREMENT,
  `kat_title` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `kat_desc` varchar(255) CHARACTER SET latin1 NOT NULL,
  `sirala` int(50) NOT NULL,
  PRIMARY KEY (`kat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin5 AUTO_INCREMENT=5 ;

--
-- Tablo döküm verisi `kategoriler`
--

INSERT INTO `kategoriler` (`kat_id`, `kat_title`, `kat_desc`, `sirala`) VALUES
(1, 'Ýlk kategorim 5566', ' ilk kategorinin açýklamasý    66    ', 5),
(2, 'ikinci kategori', 'ikinci kategori tarifi', 10),
(3, 'wwwwwwwwwww', 'wwwwwwwwwwwwwwwwww', 11);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `konular`
--

CREATE TABLE IF NOT EXISTS `konular` (
  `konu_id` int(50) NOT NULL AUTO_INCREMENT,
  `konu_kat_id` varchar(500) NOT NULL,
  `konu_forum_id` varchar(50) NOT NULL,
  `konu_mod` varchar(255) NOT NULL,
  `konu_durum` varchar(255) NOT NULL,
  `konu_baslik` varchar(1000) NOT NULL,
  `konu_goruntulenme` varchar(20) NOT NULL,
  `konu_cevap_sayisi` varchar(20) NOT NULL DEFAULT '0',
  `konu_zamani` varchar(255) NOT NULL,
  `konu_author` varchar(255) NOT NULL,
  `konu_author_id` varchar(100) NOT NULL,
  `konu_author_ip` varchar(100) NOT NULL,
  `konu_ikonu` varchar(200) NOT NULL,
  `son_mesaj_id` varchar(50) NOT NULL,
  `son_mesaj_zamani` varchar(200) NOT NULL,
  `son_mesaj_yazar` varchar(300) NOT NULL,
  `son_mesaj_yazar_id` varchar(300) NOT NULL,
  PRIMARY KEY (`konu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Tablo döküm verisi `konular`
--

INSERT INTO `konular` (`konu_id`, `konu_kat_id`, `konu_forum_id`, `konu_mod`, `konu_durum`, `konu_baslik`, `konu_goruntulenme`, `konu_cevap_sayisi`, `konu_zamani`, `konu_author`, `konu_author_id`, `konu_author_ip`, `konu_ikonu`, `son_mesaj_id`, `son_mesaj_zamani`, `son_mesaj_yazar`, `son_mesaj_yazar_id`) VALUES
(1, '', '5', 'normal', '', 'Ýlk konu', '26', '3', '1346764628', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '137', '1347818923', 'admin', '18'),
(2, '', '4', 'normal', '', 'defdsfdsf', '164', '22', '1346764659', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '131', '1347314779', 'admin', '18'),
(3, '', '2', 'normal', '', 'rewrew', '99', '22', '1346764673', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '105', '1347143244', 'admin', '18'),
(4, '', '1', 'normal', '', 'rewrewre', '62', '9', '1346764689', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '83', '1347122272', 'admin', '18'),
(5, '', '3', 'normal', '', 'rewrewre', '22', '3', '1346764697', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '136', '1347660586', 'admin', '18'),
(7, '', '1', 'normal', '', 'ewrewrew', '76', '8', '1346765573', 'admin', '18', '127.0.0.1', 'resim/icons/icon2.gif', '152', '1349782725', 'admin', '18'),
(8, '', '1', 'normal', '', 'REWREWREW', '52', '6', '1346943629', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '120', '1347247519', 'trojen', '19'),
(9, '', '2', 'normal', '', 'rewrewrewrewrew', '54', '4', '1346980666', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '146', '1349048152', 'admin', '18'),
(11, '', '2', 'normal', '', 'Duyuru olacak', '103', '13', '1346984321', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '50', '1347056870', 'admin', '18'),
(13, '', '4', 'normal', '', 'Hangisi Ama ?', '83', '2', '1347026158', 'trojen', '19', '127.0.0.1', 'resim/icons/icon5.gif', '127', '1347287727', 'admin', '18'),
(14, '', '2', 'normal', '', 'Þöyle adam gibi kod felan', '48', '3', '1347107434', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '76', '1347110698', 'admin', '18'),
(15, '', '1', 'normal', '', 'r ewrewr ewer werw', '28', '2', '1347127125', 'admin', '18', '127.0.0.1', 'resim/icons/icon9.gif', '110', '1347194688', 'admin', '18'),
(16, '', '5', 'duyuru', '', 'Duyuru olacak', '27', '2', '1347145278', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '143', '1349047842', 'admin', '18'),
(18, '', '3', 'normal', '', 'Hangisi Ama ?', '6', '0', '1347218190', 'trojen', '19', '127.0.0.1', 'resim/icons/icon1.gif', '', '1347218190', 'trojen', '19'),
(19, '', '3', 'normal', '', 'tttttttttt', '1', '0', '1347218561', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '', '1347218561', 'admin', '18'),
(20, '', '3', 'normal', '', 'rrrrrrrrrrrrrr', '19', '0', '1347218577', 'trojen', '19', '127.0.0.1', 'resim/icons/icon1.gif', '', '1347218577', 'trojen', '19'),
(21, '', '1', 'normal', '', 'Duyuru olacak', '50', '1', '1347220137', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '133', '1347343227', 'trojen', '19'),
(22, '', '1', 'duyuru', '', 'Duyuru olacak', '11', '0', '1347247164', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '', '1347247164', 'admin', '18'),
(23, '', '4', 'normal', '', 'selam dostum nasýl gidiyor', '52', '3', '1347255146', 'aspendos', '32', '127.0.0.1', 'resim/icons/icon1.gif', '128', '1347293339', 'trojen', '19'),
(25, '', '2', 'normal', '', 'rwerew', '29', '0', '1347343205', 'trojen', '19', '127.0.0.1', 'resim/icons/icon1.gif', '', '1347343205', 'trojen', '19'),
(26, '', '3', 'normal', '', 'TROJENDEN SELAM', '13', '0', '1349046614', 'trojen', '19', '127.0.0.1', 'resim/icons/icon1.gif', '', '1349046614', 'trojen', '19'),
(27, '', '5', 'normal', '', 'Anket', '15', '0', '1349213729', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '', '1349213729', 'admin', '18'),
(28, '', '2', 'normal', '', 'rrrrrrrr', '12', '0', '1349460003', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '', '1349460003', 'admin', '18'),
(29, '', '1', 'normal', '', 'rewrewrewrewrew', '14', '1', '1349572303', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '157', '1349789691', 'admin', '18'),
(30, '', '1', 'normal', '', 'yyyyyyyyyyyy', '3', '1', '1349572376', 'admin', '18', '127.0.0.1', 'resim/icons/icon1.gif', '151', '1349574058', 'admin', '18'),
(31, '1', '2', 'normal', '', 'Bu güzel olacak', '5', '1', '1349785753', 'admin', '18', '127.0.0.1', 'resim/icons/icon12.gif', '154', '1349785876', 'admin', '18'),
(32, '1', '2', 'normal', '', 'Züpper Anket', '13', '0', '1349786184', 'admin', '18', '127.0.0.1', 'resim/icons/icon13.gif', '', '1349786184', 'admin', '18'),
(33, '2', '4', 'sabit', '', 'Sabit konu olacak', '13', '1', '1353431666', 'admin', '18', '127.0.0.1', 'resim/icons/icon3.gif', '160', '1353439670', 'admin', '18'),
(34, '3', '8', 'normal', '', 'rerer er', '4', '1', '1353431980', 'admin', '18', '127.0.0.1', 'resim/icons/icon11.gif', '161', '1353448398', 'admin', '18');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

CREATE TABLE IF NOT EXISTS `kullanicilar` (
  `kul_id` int(100) NOT NULL AUTO_INCREMENT,
  `kul_adi` varchar(255) NOT NULL,
  `kul_sifre_hash` varchar(255) NOT NULL,
  `kul_sifre` varchar(255) NOT NULL,
  `kul_hatirla_hash` varchar(300) NOT NULL,
  `kul_ip` varchar(250) NOT NULL,
  `kul_agent` varchar(250) NOT NULL,
  `kul_yetki` varchar(100) NOT NULL,
  `kul_group_id` varchar(100) NOT NULL,
  `kul_grup_name` varchar(250) NOT NULL,
  `kul_grup_color` varchar(250) NOT NULL,
  `kul_email` varchar(255) NOT NULL,
  `kul_pm_istiyor_mu` varchar(100) NOT NULL,
  `kul_pm_uyari` varchar(100) NOT NULL,
  `kul_dogum_tarihi` varchar(50) NOT NULL,
  `kul_imza` varchar(400) NOT NULL,
  `kul_avatar` varchar(500) NOT NULL,
  `kul_avatar_url` varchar(500) NOT NULL,
  `kul_kayit_zamani` varchar(255) NOT NULL,
  `kul_tarih_modu` varchar(100) NOT NULL,
  `kul_son_aktivite` varchar(40) NOT NULL,
  `kul_son_giris` varchar(255) NOT NULL,
  `kul_son_cikis` varchar(255) NOT NULL DEFAULT '0',
  `kul_tema` varchar(255) NOT NULL,
  `kul_son_sayfa` varchar(300) NOT NULL,
  `kul_son_sayfa_baslik` varchar(500) NOT NULL,
  `kul_gizli_mi` varchar(255) NOT NULL,
  `kul_uyelik_amac` varchar(500) NOT NULL,
  `kul_yahoo` varchar(100) NOT NULL,
  `kul_msn` varchar(100) NOT NULL,
  `kul_aim` varchar(100) NOT NULL,
  `kul_skype` varchar(100) NOT NULL,
  `kul_icq` varchar(100) NOT NULL,
  `kul_biyografi` varchar(1000) NOT NULL,
  `kul_yer` varchar(100) NOT NULL,
  `kul_hobi` varchar(500) NOT NULL,
  `kul_meslek` varchar(100) NOT NULL,
  `kul_cinsiyet` varchar(255) NOT NULL,
  `kul_yas` varchar(255) NOT NULL,
  `kul_gercek_ad` varchar(255) NOT NULL,
  PRIMARY KEY (`kul_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Tablo döküm verisi `kullanicilar`
--

INSERT INTO `kullanicilar` (`kul_id`, `kul_adi`, `kul_sifre_hash`, `kul_sifre`, `kul_hatirla_hash`, `kul_ip`, `kul_agent`, `kul_yetki`, `kul_group_id`, `kul_grup_name`, `kul_grup_color`, `kul_email`, `kul_pm_istiyor_mu`, `kul_pm_uyari`, `kul_dogum_tarihi`, `kul_imza`, `kul_avatar`, `kul_avatar_url`, `kul_kayit_zamani`, `kul_tarih_modu`, `kul_son_aktivite`, `kul_son_giris`, `kul_son_cikis`, `kul_tema`, `kul_son_sayfa`, `kul_son_sayfa_baslik`, `kul_gizli_mi`, `kul_uyelik_amac`, `kul_yahoo`, `kul_msn`, `kul_aim`, `kul_skype`, `kul_icq`, `kul_biyografi`, `kul_yer`, `kul_hobi`, `kul_meslek`, `kul_cinsiyet`, `kul_yas`, `kul_gercek_ad`) VALUES
(1, 'teraw0rm', '@0H5MKG#cXk99r5', '2ccce02549031cb12a44d96cb967cc8f2ebde7fe', 'Fu1_R!X5]{$HM4kD-oz5v6PE]+Hv2D1347300661', '', '', '', '2', 'Normal Kullanici', '000000', 'ceyhansuyu@gmail.com', 'evet', 'evet', '15.09.1986', 'aha bu benim imzamdýr iþte', '', '', 'bugun', '3', '1347300387', '1347300661', '1347300712', 'bos deðil ', 'sistem/cikis.php', 'Çýkýþ Yapýldý', '0', 'Yazdýðým forumu denemek için ', 'yahom yok', 'msnem yok', 'aim yok', 'skype yok', 'icq yok', 'öylesine boktan bir adam', 'kayseri', 'hobim bilgisayar', 'salla gitsin', 'Erkek', '', ''),
(18, 'admin', '4sNY]pHH*?I44[l', '078543d9196b987043abe02dd8cbc571fa36bca6', 'J*n*vR_$HTNnJT!q(d+{pXp8YR6pl@1353272918', '127.0.0.1', 'Mozilla/5.0 (Windows NT 5.1; rv:17.0) Gecko/17.0 Firefox/17.0', 'admin', '1', 'Yoneticiler', 'F20C68', 'ornek@mail.com', 'hayir', 'evet', '15.09.19852', '<strong><span style="color: #800080;">aha bu benim imzamdýr iþte :)</span></strong>', 'resim/avatar/Blood.png', '', '1312560213', '3', '1353448772', '1353448550', '1353448536', '', 'showthread.php?t=33', ' - Sabit konu olacak', '0', 'Üyelik amacým forumu sýfýrdan inþaa  etmek ve php kodlamak62 ererere', 'yahoo yok262', 'msnem de yok562', 'aim de yok562', 'skype da yok562', 'icq da yok562', 'biyografim iþte562', 'kayseri562', 'p562hp kodlamak, balýk tutmak pc ile uðrþmak format atmak vs', 'tekstil müh.562', 'Erkek', '262', 'Tufan Kursat2'),
(19, 'trojen', 'dM25xf[M6NgL$0i', 'c66c82cae315aa3167dc6e52a5269586c8d3e1c9', 'nD9t6@q4wcMPzG-Hq+u489jB1NYkbj1349717498', '127.0.0.1', 'Mozilla/5.0 (Windows NT 5.1; rv:15.0) Gecko/20100101 Firefox/15.0.1', '', '2', '', '', 'tro@tro.com', 'evet', 'evet', '15.09.1986', 'trojen in imzasý', '', '', '1314287938', '3', '1349717262', '1349717498', '1349717564', 'bos deðil', 'sistem/cikis.php', 'Çýkýþ Yapýldý', '0', '', '', '', '', '', '', '', '', '', '', 'Erkek', '', ''),
(21, 'ferrari', '', '39dfa55283318d31afe5a3ff4a0e3253e2045e43', 'YKdY{E+oUhp}RBY}KPa!fOL##-awrM1347255002', '', '', '0', '2', 'Normal Kullanici', '000000', 'ferrari@ferrari.com', 'evet', 'evet', '', '', '', '', '1333932966', '', '1347288120', '1347255003', '1347254886', '', 'showthread.php?t=13', ' - Hangisi Ama ?', '0', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(28, 'tufan kursat', '', 'f7703da5a7f255cf3d4db062f13defb5e18a08cc', '(nbsXP8}I*j5BTq@2WG}w$OnU-Bdq]1334085921', '', '', '0', '2', 'Normal Kullanici', '000000', 'tufan@kursat.com', 'evet', 'evet', '', '', '', '', '1334084681', '', '', '1334090027', '0', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(29, 'petaw0rm', '', 'f7703da5a7f255cf3d4db062f13defb5e18a08cc', '', '', '', '0', '2', 'Normal Kullanici', '000000', 'petaw0rm@petaw0rm.com', 'evet', 'evet', '', '', '', '', '1334085752', '', '', '', '0', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(30, 'tarantula', '', '39dfa55283318d31afe5a3ff4a0e3253e2045e43', '*jT!g?-l-pjG{)7Azfglm!UOMjZgO-1334730374', '', '', '0', '2', 'Normal Kullanici', '000000', 'tarantula@tarantula.com', 'evet', 'evet', '', '', '', '', '1334500576', '', '', '1334730374', '1334727538', '', 'showthread.php?t=26&sayfa=1', ' - Son ziyaretiniz Bugün,10:39', '0', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(31, 'trojen2', '', '39dfa55283318d31afe5a3ff4a0e3253e2045e43', '', '', '', '0', '2', '', '', 'trojen2@gmail.com', 'evet', 'evet', '', '', '', '', '1346222079', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(32, 'aspendos', 'WE37PYoC4uy5[@D', 'e3e2e5b5685160d2e393df24832515d45a0e67f0', 'Fxkwc30j7(}vySbhoNO-PJAvAx-6}G1349128882', '127.0.0.1', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.4 (KHTML, like Gecko) Chrome/22.0.1229.79 Safari/537.4', '0', '2', '', '', 'aspendos@aspendos.com', 'evet', 'evet', '', '', 'resim/avatar/Lime.png', '', '1346587031', '', '1349129024', '1349128882', '1347287827', '', 'ozel_mesaj.php', ' - Özel Mesaj', '0', '', '', '', '', '', '', '', '', '', '', 'Erkek', '', ''),
(33, 'hash', '*oyEpa}UJz]2?BJ', 'd98cde005337c9389ca524a3490d6965d9da4ff6', 'mcnGjz]U7B#j?zSrc-S2BkX]q}Tq9I1347292928', '', '', '0', '2', '', '', 'hash@hash.com', 'evet', 'evet', '', '', '', '', '1347289107', '', '1347292631', '1347292928', '1347292936', '', 'sistem/cikis.php', 'Çýkýþ Yapýldý', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(34, 'gix', ']P}K5+YR}fixzZ_', '2380d8e53c00b75d6b4affd9ff0ddafa60d20e5e', '', '', '', '0', '2', '', '', 'gix@gix.com', '', '', '', '', '', '', '1347729713', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kul_gruplari`
--

CREATE TABLE IF NOT EXISTS `kul_gruplari` (
  `grup_id` int(50) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(250) NOT NULL,
  `group_desc` varchar(500) NOT NULL,
  `group_rutbesi` varchar(100) NOT NULL,
  `group_rutbe_resmi` varchar(500) NOT NULL,
  `group_color` varchar(100) NOT NULL,
  PRIMARY KEY (`grup_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Tablo döküm verisi `kul_gruplari`
--

INSERT INTO `kul_gruplari` (`grup_id`, `group_name`, `group_desc`, `group_rutbesi`, `group_rutbe_resmi`, `group_color`) VALUES
(1, 'Yöneticiler', 'Forum yönetiminle görevli kiþiler.', 'Administrator', 'rank_admin.gif', 'EB0000'),
(2, 'Normal Kullanýcý', 'Normal Kullanýcý Grubu', 'Normal Kul', 'rank_0.gif', '088EA3'),
(3, 'Web Ekibi', 'Forum yönetiminle görevli kiþiler.', 'WebEkip', 'rank_website.gif', '25A10D');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kul_grup_izinler`
--

CREATE TABLE IF NOT EXISTS `kul_grup_izinler` (
  `izin_id` int(255) NOT NULL AUTO_INCREMENT,
  `grup_id` varchar(100) NOT NULL,
  `forum_okuma` varchar(100) NOT NULL,
  `forum_acma` varchar(100) NOT NULL,
  `forum_duzenleme` varchar(100) NOT NULL,
  `forum_silme` varchar(255) NOT NULL,
  `forum_kilitli_konu_acma` varchar(255) NOT NULL,
  `forumlara_abonelik` varchar(255) NOT NULL,
  `cevap_yazma` varchar(100) NOT NULL,
  `anket_acma` varchar(100) NOT NULL,
  `anket_okuma` varchar(100) NOT NULL,
  `anket_duzenleme` varchar(100) NOT NULL,
  PRIMARY KEY (`izin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Tablo döküm verisi `kul_grup_izinler`
--

INSERT INTO `kul_grup_izinler` (`izin_id`, `grup_id`, `forum_okuma`, `forum_acma`, `forum_duzenleme`, `forum_silme`, `forum_kilitli_konu_acma`, `forumlara_abonelik`, `cevap_yazma`, `anket_acma`, `anket_okuma`, `anket_duzenleme`) VALUES
(1, '1', 'evet', 'evet', 'evet', 'evet', 'evet', 'evet', 'evet', 'evet', 'evet', 'evet'),
(2, '2', 'evet', 'evet', 'hayir', 'hayir', 'hayir', 'hayir', 'evet', 'hayir', 'evet', 'hayir');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mesajlar`
--

CREATE TABLE IF NOT EXISTS `mesajlar` (
  `mesaj_id` int(50) NOT NULL AUTO_INCREMENT,
  `mesaj_konu_id` varchar(20) NOT NULL,
  `mesaj_forum_id` varchar(255) NOT NULL,
  `mesaj_kat_id` varchar(500) NOT NULL,
  `mesaj_durum` varchar(255) NOT NULL,
  `mesaj_zamani` varchar(100) NOT NULL,
  `mesaj_author` varchar(100) NOT NULL,
  `mesaj_author_id` varchar(100) NOT NULL,
  `mesaj_author_ip` varchar(100) NOT NULL,
  `mesaj_baslik` varchar(255) NOT NULL,
  `mesaj_govde` longtext NOT NULL,
  `mesaj_ikonu` varchar(200) NOT NULL,
  `mesaj_edit_sebep` varchar(300) NOT NULL,
  `mesaj_edit_zaman` varchar(100) NOT NULL,
  `mesaj_edit_kim` varchar(300) NOT NULL,
  `mesaj_edit_kim_id` varchar(100) NOT NULL,
  `mesaj_edit_sayisi` varchar(100) NOT NULL,
  PRIMARY KEY (`mesaj_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=162 ;

--
-- Tablo döküm verisi `mesajlar`
--

INSERT INTO `mesajlar` (`mesaj_id`, `mesaj_konu_id`, `mesaj_forum_id`, `mesaj_kat_id`, `mesaj_durum`, `mesaj_zamani`, `mesaj_author`, `mesaj_author_id`, `mesaj_author_ip`, `mesaj_baslik`, `mesaj_govde`, `mesaj_ikonu`, `mesaj_edit_sebep`, `mesaj_edit_zaman`, `mesaj_edit_kim`, `mesaj_edit_kim_id`, `mesaj_edit_sayisi`) VALUES
(1, '1', '5', '', 'konu', '1346764628', 'admin', '18', '127.0.0.1', 'Ýlk konu', 'deneme', 'resim/icons/icon1.gif', '', '', '', '', ''),
(2, '2', '4', '', 'konu', '1346764659', 'admin', '18', '127.0.0.1', 'defdsfdsf', 'dsfdfsdfdsfds', 'resim/icons/icon1.gif', '', '', '', '', ''),
(3, '3', '2', '', 'konu', '1346764673', 'admin', '18', '127.0.0.1', 'rewrew', 'rewrewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(4, '4', '1', '', 'konu', '1346764689', 'admin', '18', '127.0.0.1', 'rewrewre', 'wrewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(5, '5', '3', '', 'konu', '1346764697', 'admin', '18', '127.0.0.1', 'rewrewre', 'wrewrewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(8, '7', '1', '', 'konu', '1346765573', 'admin', '18', '127.0.0.1', 'ewrewrew', 'rwerewrewrewrewrew', 'resim/icons/icon2.gif', '', '1346861353', 'admin', '18', '1'),
(9, '3', '2', '', '', '1346765924', 'admin', '18', '127.0.0.1', 'Re: rewrew', 'rwerewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(10, '3', '2', '', '', '1346765927', 'admin', '18', '127.0.0.1', 'Re: rewrew', 'rewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(11, '3', '2', '', '', '1346765929', 'admin', '18', '127.0.0.1', 'Re: rewrew', 'rewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(12, '3', '2', '', '', '1346765932', 'admin', '18', '127.0.0.1', 'Re: rewrew', 'rewrewrewrew', 'resim/icons/icon1.gif', '', '1346806210', 'admin', '18', '1'),
(13, '3', '2', '', '', '1346765935', 'admin', '18', '127.0.0.1', 'Re: rewrew', 'rewrewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(14, '3', '2', '', '', '1346765938', 'admin', '18', '127.0.0.1', 'Re: rewrew', 'rewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(15, '3', '2', '', '', '1346765940', 'admin', '18', '127.0.0.1', 'Re: rewrew', 'rewrewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(16, '3', '2', '', '', '1346765943', 'admin', '18', '127.0.0.1', 'Re: rewrew', 'rewrewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(17, '3', '2', '', '', '1346765948', 'admin', '18', '127.0.0.1', 'Re: rewrew', 'rewrewrewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(18, '3', '2', '', '', '1346806283', 'admin', '18', '127.0.0.1', 'Re: rewrew', 'oyun', 'resim/icons/icon1.gif', '', '', '', '', ''),
(19, '2', '4', '', '', '1346806294', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'oyun', 'resim/icons/icon1.gif', '', '', '', '', ''),
(21, '7', '1', '', '', '1346866513', 'admin', '18', '127.0.0.1', 'Re: ewrewrew', 'rewr wer ewrew rewr ew', 'resim/icons/icon5.gif', '', '1346967840', 'admin', '18', '1'),
(22, '8', '1', '', 'konu', '1346943629', 'admin', '18', '127.0.0.1', 'REWREWREW', '[S]REWREW[/S] REWR [QUOTE]EWREWREW[/QUOTE] REW [CODE]REWREW[/CODE] REWR [PHP]EWREWRE[/PHP]&nbsp;\r\n[YOUTUBE]aAi9VZ-vGuE[/YOUTUBE]', 'resim/icons/icon1.gif', '', '1346944022', 'admin', '18', '2'),
(23, '8', '1', '', '', '1346943849', 'admin', '18', '127.0.0.1', 'Re: REWREWREW', '<strong>rewrew rewr </strong><span style="color: #ff0000;">ewrewrew erw rewre <span style="background-color: #888888;">wrew rewrew rewrew</span></span>', 'resim/icons/icon1.gif', '', '', '', '', ''),
(24, '8', '1', '', '', '1346943866', 'admin', '18', '127.0.0.1', 'Re: REWREWREW', '[CODE]r werew[/CODE][PHP] rew ewre[/PHP]rew[YOUTUBE] rewrew[/YOUTUBE]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(25, '8', '1', '', '', '1346963854', 'admin', '18', '127.0.0.1', 'Re: REWREWREW', '&lt;script&gt;', 'resim/icons/icon1.gif', '', '', '', '', ''),
(26, '9', '2', '', 'konu', '1346980666', 'admin', '18', '127.0.0.1', 'rewrewrewrewrew', '<img src="resim/smilies/eek.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '1347122657', 'admin', '18', '2'),
(28, '11', '2', '', 'konu', '1346984321', 'admin', '18', '127.0.0.1', 'Duyuru olacak', 'rrew rew rewrew rewrew<img src="resim/smilies/O_o.png" alt="" width="18" height="18" /><img src="resim/smilies/alien.png" alt="" width="18" height="18" /><img src="resim/smilies/barefoot.png" alt="" width="18" height="18" /><img src="resim/smilies/biggrin.png" alt="" width="18" height="18" /><img src="resim/smilies/cautious.png" alt="" width="18" height="18" /><img src="resim/smilies/coffee.png" alt="" width="18" height="18" /><img src="resim/smilies/confused.png" alt="" width="18" height="18" /><img src="resim/smilies/cool.png" alt="" width="18" height="18" /><img src="resim/smilies/cry.png" alt="" width="18" height="18" /><img src="resim/smilies/devilish.png" alt="" width="18" height="18" /><img src="resim/smilies/eek.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" /><img src="resim/smilies/geek.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/inlove.png" alt="" width="18" height="18" /><img src="resim/smilies/laugh.png" alt="" width="18" height="18" /><img src="resim/smilies/mad.png" alt="" width="18" height="18" /><img src="resim/smilies/ninja.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" /><img src="resim/smilies/roflmao.png" alt="" width="18" height="18" /><img src="resim/smilies/redface.png" alt="" width="18" height="18" /><img src="resim/smilies/rolleyes.png" alt="" width="18" height="18" /><img src="resim/smilies/sick.png" alt="" width="18" height="18" /><img src="resim/smilies/sleep.png" alt="" width="18" height="18" /><img src="resim/smilies/smile.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsup.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsdown.png" alt="" width="18" height="18" /><img src="resim/smilies/speechless.png" alt="" width="18" height="18" /><img src="resim/smilies/sneaky.png" alt="" width="18" height="18" /><img src="resim/smilies/tongue.png" alt="" width="18" height="18" /><img src="resim/smilies/unsure.png" alt="" width="18" height="18" /><img src="resim/smilies/whistling.png" alt="" width="18" height="18" /><img src="resim/smilies/wink.png" alt="" width="18" height="18" /><img src="resim/smilies/x3.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(32, '11', '2', '', '', '1346986260', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', '<img src="resim/smilies/cautious.png" alt="" width="18" height="18" /><img src="resim/smilies/cry.png" alt="" width="18" height="18" /><img src="resim/smilies/devilish.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" /><img src="resim/smilies/sick.png" alt="" width="18" height="18" /><img src="resim/smilies/sneaky.png" alt="" width="18" height="18" /><img src="resim/smilies/tongue.png" alt="" width="18" height="18" /><img src="resim/smilies/x3.png" alt="" width="18" height="18" /><img src="resim/smilies/wink.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsup.png" alt="" width="18" height="18" /><img src="resim/smilies/smile.png" alt="" width="18" height="18" /><img src="resim/smilies/roflmao.png" alt="" width="18" height="18" /><img src="resim/smilies/mad.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '1347027308', 'trojen', '19', '1'),
(33, '7', '1', '', '', '1347025956', 'admin', '18', '127.0.0.1', 'Re: ewrewrew', '<img src="resim/smilies/cautious.png" alt="" width="18" height="18" /><img src="resim/smilies/coffee.png" alt="" width="18" height="18" /><img src="resim/smilies/confused.png" alt="" width="18" height="18" /><img src="resim/smilies/cool.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" /><img src="resim/smilies/laugh.png" alt="" width="18" height="18" /><img src="resim/smilies/redface.png" alt="" width="18" height="18" /><img src="resim/smilies/sleep.png" alt="" width="18" height="18" /><img src="resim/smilies/sick.png" alt="" width="18" height="18" /><img src="resim/smilies/rolleyes.png" alt="" width="18" height="18" /><img src="resim/smilies/sneaky.png" alt="" width="18" height="18" /><img src="resim/smilies/tongue.png" alt="" width="18" height="18" /><img src="resim/smilies/x3.png" alt="" width="18" height="18" /><img src="resim/smilies/wink.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsup.png" alt="" width="18" height="18" /><img src="resim/smilies/smile.png" alt="" width="18" height="18" /><img src="resim/smilies/roflmao.png" alt="" width="18" height="18" /><img src="resim/smilies/mad.png" alt="" width="18" height="18" /><img src="resim/smilies/geek.png" alt="" width="18" height="18" />', 'resim/icons/icon2.gif', '', '', '', '', ''),
(34, '7', '1', '', '', '1347026007', 'trojen', '19', '127.0.0.1', 'Re: ewrewrew', '<img src="resim/smilies/mad.png" alt="" width="18" height="18" /><img src="resim/smilies/ninja.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" /><img src="resim/smilies/laugh.png" alt="" width="18" height="18" />', 'resim/icons/icon2.gif', '', '', '', '', ''),
(35, '13', '4', '', 'konu', '1347026158', 'trojen', '19', '127.0.0.1', 'Hangisi Ama ?', 'Antivir&uuml;s kuracam ama hangisi <img src="resim/smilies/cautious.png" alt="" width="18" height="18" /><img src="resim/smilies/biggrin.png" alt="" width="18" height="18" />', 'resim/icons/icon5.gif', '', '1347026453', 'trojen', '19', '1'),
(36, '13', '4', '', '', '1347026473', 'trojen', '19', '127.0.0.1', 'Hangisi Ama ?', '[QUOTE=trojen] Antivir&uuml;s kuracam ama hangisi <img src="resim/smilies/cautious.png" alt="" width="18" height="18" /><img src="resim/smilies/biggrin.png" alt="" width="18" height="18" />[/QUOTE] ewq ewqew qweq<img src="resim/smilies/redface.png" alt="" width="18" height="18" /><img src="resim/smilies/rolleyes.png" alt="" width="18" height="18" /><img src="resim/smilies/tongue.png" alt="" width="18" height="18" /><img src="resim/smilies/x3.png" alt="" width="18" height="18" /><img src="resim/smilies/wink.png" alt="" width="18" height="18" />', 'resim/icons/icon5.gif', '', '', '', '', ''),
(38, '8', '1', '', '', '1347029719', 'admin', '18', '127.0.0.1', 'Re: REWREWREW', '<img src="resim/smilies/confused.png" alt="" width="18" height="18" /><img src="resim/smilies/biggrin.png" alt="" width="18" height="18" /><img src="resim/smilies/cool.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" /><img src="resim/smilies/laugh.png" alt="" width="18" height="18" /><img src="resim/smilies/roflmao.png" alt="" width="18" height="18" /><img src="resim/smilies/redface.png" alt="" width="18" height="18" /><img src="resim/smilies/sleep.png" alt="" width="18" height="18" /><img src="resim/smilies/smile.png" alt="" width="18" height="18" /><img src="resim/smilies/sneaky.png" alt="" width="18" height="18" /><img src="resim/smilies/tongue.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsup.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsdown.png" alt="" width="18" height="18" /><img src="resim/smilies/whistling.png" alt="" width="18" height="18" /><img src="resim/smilies/wink.png" alt="" width="18" height="18" /><img src="resim/smilies/x3.png" alt="" width="18" height="18" /><img src="resim/smilies/unsure.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(39, '4', '1', '', '', '1347035100', 'admin', '18', '127.0.0.1', 'Re: rewrewre', '[PHP] while($row=mysql_fetch_array($sql)) { echo "nbr"; } [/PHP]', 'resim/icons/icon1.gif', '', '1347035907', 'admin', '18', '1'),
(40, '4', '1', '', '', '1347040253', 'admin', '18', '127.0.0.1', 'Re: rewrewre', '<img src="resim/smilies/unsure.png" alt="" width="18" height="18" /><img src="resim/smilies/speechless.png" alt="" width="18" height="18" /><img src="resim/smilies/sick.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/devilish.png" alt="" width="18" height="18" /><img src="resim/smilies/eek.png" alt="" width="18" height="18" /><img src="resim/smilies/inlove.png" alt="" width="18" height="18" /><img src="resim/smilies/redface.png" alt="" width="18" height="18" /><img src="resim/smilies/sleep.png" alt="" width="18" height="18" /><img src="resim/smilies/rolleyes.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(41, '11', '2', '', '', '1347049821', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', '[PHP]echo nbr?[/PHP]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(42, '11', '2', '', '', '1347052910', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', '[PHP]&lt;php $kul ="rewrewrew"; echo "rewre"; ?&gt;[/PHP]', 'resim/icons/icon1.gif', '', '1347053012', 'admin', '18', '2'),
(43, '11', '2', '', '', '1347053922', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', 'rewre wrewrewr', 'resim/icons/icon1.gif', '', '', '', '', ''),
(44, '11', '2', '', '', '1347053933', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', '[QUOTE=admin] [PHP]echo nbr[/PHP][/QUOTE] erwr ewrew rewe ew', 'resim/icons/icon1.gif', '', '1347055382', 'admin', '18', '1'),
(45, '11', '2', '', '', '1347055156', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', '[QUOTE]tretretretre[/QUOTE]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(46, '11', '2', '', '', '1347055794', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', '[QUOTE=admin] [QUOTE=admin] [PHP]echo nbr[/PHP][/QUOTE] erwr ewrew rewe ew[/QUOTE]rer ewrewr ew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(47, '11', '2', '', '', '1347055915', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', '[QUOTE] [QUOTE] [QUOTE=admin] [PHP]echo nbr[/PHP][/QUOTE] erwr ewrew rewe ew[/QUOTE]rer ewrewr ew[/QUOTE]', 'resim/icons/icon1.gif', '', '1347055957', 'admin', '18', '1'),
(48, '11', '2', '', '', '1347055976', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', '[QUOTE] [QUOTE] [QUOTE] [QUOTE=admin] [PHP]echo nbr[/PHP][/QUOTE] erwr ewrew rewe ew[/QUOTE]rer ewrewr ew[/QUOTE][/QUOTE] erwrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(49, '11', '2', '', '', '1347056152', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', '[QUOTE=admin] [QUOTE] [QUOTE] [QUOTE] [QUOTE=admin] [PHP]echo nbr[/PHP][/QUOTE] erwr ewrew rewe ew[/QUOTE]rer ewrewr ew[/QUOTE][/QUOTE] erwrew[/QUOTE]tufan', 'resim/icons/icon1.gif', '', '', '', '', ''),
(50, '11', '2', '', '', '1347056870', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', '[QUOTE=admin] [QUOTE=admin] [QUOTE] [QUOTE] [QUOTE] [QUOTE=admin] [PHP]echo nbr[/PHP][/QUOTE] erwr ewrew rewe ew[/QUOTE]rer ewrewr ew[/QUOTE][/QUOTE] erwrew[/QUOTE]tufan[/QUOTE]tretretretre', 'resim/icons/icon1.gif', '', '', '', '', ''),
(51, '3', '2', '', '', '1347057223', 'admin', '18', '127.0.0.1', 'Re: rewrew', '[QUOTE=admin] oyun[/QUOTE]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(52, '3', '2', '', '', '1347057248', 'admin', '18', '127.0.0.1', 'Re: rewrew', '[QUOTE=admin] [QUOTE=admin] oyun[/QUOTE][/QUOTE]rw erwrewerwerw', 'resim/icons/icon1.gif', '', '', '', '', ''),
(53, '3', '2', '', '', '1347057311', 'admin', '18', '127.0.0.1', 'Re: rewrew', '[QUOTE=admin] [QUOTE=admin] [QUOTE=admin] oyun[/QUOTE][/QUOTE]rw erwrewerwerw[/QUOTE]ewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(54, '3', '2', '', '', '1347057472', 'admin', '18', '127.0.0.1', 'Re: rewrew', 'ewrewrew', 'resim/icons/icon1.gif', '', '1347057494', 'admin', '18', '1'),
(55, '3', '2', '', '', '1347057505', 'admin', '18', '127.0.0.1', 'Re: rewrew', '[QUOTE=admin] ewrewrew[/QUOTE] 1. alýntý', 'resim/icons/icon1.gif', '', '', '', '', ''),
(56, '3', '2', '', '', '1347057515', 'admin', '18', '127.0.0.1', 'Re: rewrew', '[QUOTE=admin] [QUOTE=admin] ewrewrew[/QUOTE] 1. alýntý[/QUOTE] 2. alýntý', 'resim/icons/icon1.gif', '', '', '', '', ''),
(57, '3', '2', '', '', '1347058028', 'admin', '18', '127.0.0.1', 'Re: rewrew', '[QUOTE=admin] [QUOTE=admin] [QUOTE=admin] ewrewrew[/QUOTE] 1. alýntý[/QUOTE] 2. alýntý[/QUOTE]3 . alýntý', 'resim/icons/icon1.gif', '', '', '', '', ''),
(58, '3', '2', '', '', '1347058622', 'admin', '18', '127.0.0.1', 'Re: rewrew', '[QUOTE=admin] [QUOTE=admin] [QUOTE=admin] [QUOTE=admin] ewrewrew[/QUOTE] 1. alýntý[/QUOTE] 2. alýntý[/QUOTE]3 . alýntý[/QUOTE]<span style="color: #ff0000;"><strong>4. alýntý</strong></span>', 'resim/icons/icon1.gif', '', '1347058777', 'admin', '18', '1'),
(59, '3', '2', '', '', '1347058789', 'admin', '18', '127.0.0.1', 'Re: rewrew', '[QUOTE] [QUOTE] [QUOTE] [QUOTE] [QUOTE] ewrewrew[/QUOTE] 1. alýntý[/QUOTE] 2. alýntý[/QUOTE]3 . alýntý[/QUOTE]<span style="color: #ff0000;"><strong>4. alýntý</strong></span>[/QUOTE]5. alýntý', 'resim/icons/icon1.gif', '', '1347058857', 'admin', '18', '1'),
(60, '3', '2', '', '', '1347059053', 'admin', '18', '127.0.0.1', 'Re: rewrew', '[CODE]rewr werew rew rew[/CODE]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(61, '3', '2', '', '', '1347059068', 'admin', '18', '127.0.0.1', 'Re: rewrew', '[QUOTE=admin] [CODE]rewr werew rew rew[/CODE][/QUOTE]r werewrewer', 'resim/icons/icon1.gif', '', '', '', '', ''),
(72, '14', '2', '', 'konu', '1347107434', 'admin', '18', '127.0.0.1', 'Þöyle adam gibi kod felan', '[QUOTE]ewqe wqewq we rewrew rew rew rew rew[/QUOTE] [CODE]#code[/CODE]\r\n[PHP]\r\n&lt;?php\r\n&nbsp; echo "nbr";\r\n?&gt;\r\n[/PHP]', 'resim/icons/icon1.gif', '', '1347110229', 'admin', '18', '5'),
(73, '8', '1', '', '', '1347108120', 'admin', '18', '127.0.0.1', 'Re: REWREWREW', '<img src="resim/smilies/eek.png" alt="" width="18" height="18" /><img src="resim/smilies/inlove.png" alt="" width="18" height="18" /><img src="resim/smilies/redface.png" alt="" width="18" height="18" /><img src="resim/smilies/sleep.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" /><img src="resim/smilies/sick.png" alt="" width="18" height="18" /><img src="resim/smilies/speechless.png" alt="" width="18" height="18" /><img src="resim/smilies/unsure.png" alt="" width="18" height="18" /><img src="resim/smilies/whistling.png" alt="" width="18" height="18" /><img src="resim/smilies/wink.png" alt="" width="18" height="18" /><img src="resim/smilies/x3.png" alt="" width="18" height="18" /><img src="resim/smilies/tongue.png" alt="" width="18" height="18" /><img src="resim/smilies/sneaky.png" alt="" width="18" height="18" /><img src="resim/smilies/rolleyes.png" alt="" width="18" height="18" /><img src="resim/smilies/mad.png" alt="" width="18" height="18" /><img src="resim/smilies/geek.png" alt="" width="18" height="18" /><img src="resim/smilies/cry.png" alt="" width="18" height="18" /><img src="resim/smilies/cautious.png" alt="" width="18" height="18" /><img src="resim/smilies/biggrin.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(74, '14', '2', '', '', '1347110420', 'admin', '18', '127.0.0.1', 'Þöyle adam gibi kod felan', '[QUOTE=admin] [QUOTE]ewqe wqewq we rewrew rew rew rew rew[/QUOTE] [CODE]#code[/CODE] [PHP]\r\n\r\n[/PHP][/QUOTE]rewr ewrew ', 'resim/icons/icon1.gif', '', '', '', '', ''),
(75, '14', '2', '', '', '1347110679', 'admin', '18', '127.0.0.1', 'Re: Þöyle adam gibi kod felan', '<p>[PHP]&lt;?php echo "nbr";&nbsp; ?&gt;[/PHP]</p>', 'resim/icons/icon1.gif', '', '', '', '', ''),
(76, '14', '2', '', '', '1347110698', 'admin', '18', '127.0.0.1', 'Re: Þöyle adam gibi kod felan', '[QUOTE=admin]\r\n[PHP][/PHP]\r\n[/QUOTE]w rewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(77, '4', '1', '', '', '1347116628', 'admin', '18', '127.0.0.1', 'Re: rewrewre', '[QUOTE=admin] [PHP] while($row=mysql_fetch_array($sql)) { echo "nbr"; } [/PHP][/QUOTE]EWQWEQ EWQE WQE', 'resim/icons/icon1.gif', '', '', '', '', ''),
(78, '4', '1', '', '', '1347116658', 'admin', '18', '127.0.0.1', 'Re: rewrewre', '[QUOTE=admin] [QUOTE=admin] [PHP] while($row=mysql_fetch_array($sql)) { echo "nbr"; } [/PHP][/QUOTE]EWQWEQ EWQE WQE[/QUOTE] de diyon<img src="resim/smilies/confused.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(79, '4', '1', '', '', '1347118973', 'admin', '18', '127.0.0.1', 'Re: rewrewre', '[PHP]&nbsp; &nbsp;&nbsp;&nbsp; function bb_to_html($text){<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;//$text = htmlspecialchars($text, ENT_QUOTES);<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;/**<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp; * Parse the static restrict bbcode.<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp; */ <br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;for ($i = 0; $i &lt; count($this-&gt;restrict_static_bbcode); $i += 2){<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;$pattern = ''#''.preg_quote($this-&gt;restrict_static_bbcode[$i],''#'').''(.+)''.preg_quote($this-&gt;restrict_static_bbcode[$i+1], ''#'').''#Usi'';<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;$replace = $this-&gt;restrict_static_html[$i].''$1''.$this-&gt;restrict_static_html[$i+1];<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;$text = preg_replace($pattern, $replace, $text);<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;<br />&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;} [/PHP]', 'resim/icons/icon1.gif', '', '1347119202', 'admin', '18', '2'),
(80, '4', '1', '', '', '1347119056', 'admin', '18', '127.0.0.1', 'Re: rewrewre', 'fdfdfd', 'resim/icons/icon1.gif', '', '1347121685', 'admin', '18', '1'),
(81, '4', '1', '', '', '1347121816', 'admin', '18', '127.0.0.1', 'Re: rewrewre', '[PHP]echo "selam"; [/PHP]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(82, '4', '1', '', '', '1347121853', 'admin', '18', '127.0.0.1', 'Re: rewrewre', '[QUOTE=admin] [PHP]echo "selam"; [/PHP][/QUOTE] ewe wew w wewew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(83, '4', '1', '', '', '1347122272', 'admin', '18', '127.0.0.1', 'Re: rewrewre', '[PHP]&lt;?php echo "selam";[/PHP]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(84, '15', '1', '', 'konu', '1347127125', 'admin', '18', '127.0.0.1', 'r ewrewr ewer werw', '<img src="resim/smilies/confused.png" alt="" width="18" height="18" /><img src="resim/smilies/eek.png" alt="" width="18" height="18" /><img src="resim/smilies/inlove.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" /> [QUOTE]rew rewre wr werw[/QUOTE]', 'resim/icons/icon9.gif', '', '', '', '', ''),
(85, '5', '3', '', '', '1347127216', 'admin', '18', '127.0.0.1', 'Re: rewrewre', '[PHP]rewrew rew rew[/PHP]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(86, '2', '4', '', '', '1347140122', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'rerere', 'resim/icons/icon1.gif', '', '', '', '', ''),
(87, '2', '4', '', '', '1347140124', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'rerere', 'resim/icons/icon1.gif', '', '', '', '', ''),
(88, '2', '4', '', '', '1347140127', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'rererere', 'resim/icons/icon1.gif', '', '', '', '', ''),
(89, '2', '4', '', '', '1347140130', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'trrtrtrtrtr', 'resim/icons/icon1.gif', '', '', '', '', ''),
(90, '2', '4', '', '', '1347140135', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'ytytytyt', 'resim/icons/icon1.gif', '', '', '', '', ''),
(91, '2', '4', '', '', '1347140138', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'ytytytyt', 'resim/icons/icon1.gif', '', '', '', '', ''),
(92, '2', '4', '', '', '1347140141', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'ytytytyt', 'resim/icons/icon1.gif', '', '', '', '', ''),
(93, '2', '4', '', '', '1347140144', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'ytytytytyt', 'resim/icons/icon1.gif', '', '', '', '', ''),
(94, '2', '4', '', '', '1347140147', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'ytyytyt', 'resim/icons/icon1.gif', '', '', '', '', ''),
(95, '2', '4', '', '', '1347140150', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'rereerrere', 'resim/icons/icon1.gif', '', '', '', '', ''),
(96, '2', '4', '', '', '1347140446', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'rerwewrewre', 'resim/icons/icon1.gif', '', '', '', '', ''),
(97, '2', '4', '', '', '1347142053', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', '[QUOTE=admin; yazarID=18; mesajID=19; sayfa=1] oyun[/QUOTE]erer erw rew rewew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(98, '2', '4', '', '', '1347142446', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', '[QUOTE=admin; yazarID=18; mesajID=97; sayfa=2] [QUOTE=admin; yazarID=18; mesajID=19; sayfa=1] oyun[/QUOTE]erer erw rew rewew[/QUOTE]r ewrewrew rew rew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(99, '2', '4', '', '', '1347142719', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'rrrrrrrrrr', 'resim/icons/icon1.gif', '', '', '', '', ''),
(100, '2', '4', '', '', '1347142726', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', '[yazarID=18; QUOTE=admin; sayfa=3; mesajID=99] rrrrrrrrrr[/QUOTE]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(101, '2', '4', '', '', '1347142833', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', '[QUOTE=admin; yazarID=18; mesajID=100; sayfa=3] [yazarID=18; QUOTE=admin; sayfa=3; mesajID=99] rrrrrrrrrr[/QUOTE][/QUOTE]rew rewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(103, '2', '4', '', '', '1347143034', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', '[PHP]echo "nbr";[/PHP]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(104, '2', '4', '', '', '1347143090', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', '[QUOTE=admin] [PHP]echo "nbr";[/PHP][/QUOTE] rewrew rew rew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(105, '3', '2', '', '', '1347143244', 'admin', '18', '127.0.0.1', 'Re: rewrew', '<img src="resim/smilies/eek.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(107, '16', '5', '', 'konu', '1347145278', 'admin', '18', '127.0.0.1', 'Duyuru olacak', 'eeeeeeeeeeeee<img src="resim/smilies/eek.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '1349734255', 'admin', '18', '2'),
(109, '15', '1', '', '', '1347194661', 'admin', '18', '127.0.0.1', 'Re: r ewrewr ewer werw', '<img src="resim/smilies/biggrin.png" alt="" width="18" height="18" /><img src="resim/smilies/cool.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" /><img src="resim/smilies/inlove.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" />', 'resim/icons/icon9.gif', '', '1347194670', 'admin', '18', '1'),
(110, '15', '1', '', '', '1347194688', 'admin', '18', '127.0.0.1', 'Re: r ewrewr ewer werw', '[QUOTE=admin] <img src="resim/smilies/biggrin.png" alt="" width="18" height="18" /><img src="resim/smilies/cool.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" /><img src="resim/smilies/inlove.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" />[/QUOTE] trtr trt r', 'resim/icons/icon9.gif', '', '', '', '', ''),
(112, '18', '3', '', 'konu', '1347218190', 'trojen', '19', '127.0.0.1', 'Hangisi Ama ?', 'rrrrrrrrrrrrrrrrrrrrrr', 'resim/icons/icon1.gif', '', '', '', '', ''),
(113, '19', '3', '', 'konu', '1347218561', 'admin', '18', '127.0.0.1', 'tttttttttt', 'tttttttttttttttttttttttttttttt', 'resim/icons/icon1.gif', '', '', '', '', ''),
(114, '20', '3', '', 'konu', '1347218577', 'trojen', '19', '127.0.0.1', 'rrrrrrrrrrrrrr', 'rrrrrrrrrrrrrrrrrrrrrrrrrrrr', 'resim/icons/icon1.gif', '', '', '', '', ''),
(115, '7', '1', '', '', '1347219485', 'admin', '18', '127.0.0.1', 'Re: ewrewrew', '<img src="resim/smilies/confused.png" alt="" width="18" height="18" /><img src="resim/smilies/cool.png" alt="" width="18" height="18" /><img src="resim/smilies/cry.png" alt="" width="18" height="18" /><img src="resim/smilies/mad.png" alt="" width="18" height="18" /><img src="resim/smilies/laugh.png" alt="" width="18" height="18" /><img src="resim/smilies/inlove.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" />gf fg f gf gff gf', 'resim/icons/icon2.gif', '', '', '', '', ''),
(116, '21', '1', '', 'konu', '1347220137', 'admin', '18', '127.0.0.1', 'Duyuru olacak', 'eeeeeeeeeeeeeeeeeeeeeee', 'resim/icons/icon1.gif', '', '', '', '', ''),
(117, '1', '5', '', '', '1347242450', 'trojen', '19', '127.0.0.1', 'Re: Ýlk konu', 'rew rew rewrew rew<img src="resim/smilies/giggle.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(118, '22', '1', '', 'konu', '1347247164', 'admin', '18', '127.0.0.1', 'Duyuru olacak', 'fdsf dsfd fds fds fds fds<img src="resim/smilies/inlove.png" alt="" width="18" height="18" />f dsfdsfds fds<img src="resim/smilies/roflmao.png" alt="" width="18" height="18" />f dsfds', 'resim/icons/icon1.gif', '', '', '', '', ''),
(119, '5', '3', '', '', '1347247179', 'admin', '18', '127.0.0.1', 'Re: rewrewre', 'rwe reewrew rew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(120, '8', '1', '', '', '1347247519', 'trojen', '19', '127.0.0.1', 'Re: REWREWREW', 'rewrew rew rew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(121, '23', '4', '', 'konu', '1347255146', 'aspendos', '32', '127.0.0.1', 'selam dostum nasýl gidiyor', '[PHP]ewq wqewq ewqe wqew qew qweq ewq[/PHP]<img src="resim/smilies/geek.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(122, '23', '4', '', '', '1347255292', 'aspendos', '32', '127.0.0.1', 'selam dostum nasýl gidiyor', '[QUOTE=aspendos] [PHP]ewq wqewq ewqe wqew qew qweq ewq[/PHP]<img src="resim/smilies/geek.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" />[/QUOTE]sd sds ds ds', 'resim/icons/icon1.gif', '', '', '', '', ''),
(128, '23', '4', '', '', '1347293339', 'trojen', '19', '127.0.0.1', 'Re: selam dostum nasýl gidiyor', '[QUOTE=ferrari] rew rew rew[/QUOTE] rerrew rw ewrer wrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(130, '2', '4', '', '', '1347314777', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'tretretre', 'resim/icons/icon1.gif', '', '', '', '', ''),
(131, '2', '4', '', '', '1347314779', 'admin', '18', '127.0.0.1', 'Re: defdsfdsf', 'tretretre', 'resim/icons/icon1.gif', '', '', '', '', ''),
(132, '25', '2', '', 'konu', '1347343205', 'trojen', '19', '127.0.0.1', 'rwerew', 'wrewrew ewrew rewr ewrew rew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(133, '21', '1', '', '', '1347343227', 'trojen', '19', '127.0.0.1', 'Re: Duyuru olacak', 'tretretre', 'resim/icons/icon1.gif', '', '', '', '', ''),
(134, '1', '5', '', '', '1347343263', 'trojen', '19', '127.0.0.1', 'Re: Ýlk konu', '543543 543 543<img src="resim/smilies/speechless.png" alt="" width="18" height="18" />54 354<img src="resim/smilies/sick.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(135, '7', '1', '', '', '1347534459', 'admin', '18', '127.0.0.1', 'Re: ewrewrew', '<img src="resim/smilies/coffee.png" alt="" width="18" height="18" /><img src="resim/smilies/confused.png" alt="" width="18" height="18" /><img src="resim/smilies/cool.png" alt="" width="18" height="18" /><img src="resim/smilies/cry.png" alt="" width="18" height="18" /><img src="resim/smilies/devilish.png" alt="" width="18" height="18" /><img src="resim/smilies/eek.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" /><img src="resim/smilies/geek.png" alt="" width="18" height="18" /><img src="resim/smilies/laugh.png" alt="" width="18" height="18" /><img src="resim/smilies/mad.png" alt="" width="18" height="18" /><img src="resim/smilies/inlove.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" /><img src="resim/smilies/redface.png" alt="" width="18" height="18" /><img src="resim/smilies/roflmao.png" alt="" width="18" height="18" /><img src="resim/smilies/rolleyes.png" alt="" width="18" height="18" /><img src="resim/smilies/sick.png" alt="" width="18" height="18" /><img src="resim/smilies/sleep.png" alt="" width="18" height="18" /><img src="resim/smilies/smile.png" alt="" width="18" height="18" /><img src="resim/smilies/sneaky.png" alt="" width="18" height="18" /><img src="resim/smilies/speechless.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsdown.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsup.png" alt="" width="18" height="18" /><img src="resim/smilies/tongue.png" alt="" width="18" height="18" /><img src="resim/smilies/unsure.png" alt="" width="18" height="18" /><img src="resim/smilies/whistling.png" alt="" width="18" height="18" /><img src="resim/smilies/wink.png" alt="" width="18" height="18" /><img src="resim/smilies/x3.png" alt="" width="18" height="18" />', 'resim/icons/icon2.gif', '', '', '', '', ''),
(136, '5', '3', '', '', '1347660586', 'admin', '18', '127.0.0.1', 'Re: rewrewre', '<img src="resim/smilies/O_o.png" alt="" width="18" height="18" /><img src="resim/smilies/barefoot.png" alt="" width="18" height="18" /><img src="resim/smilies/biggrin.png" alt="" width="18" height="18" /><img src="resim/smilies/cautious.png" alt="" width="18" height="18" /><img src="resim/smilies/cry.png" alt="" width="18" height="18" /><img src="resim/smilies/cool.png" alt="" width="18" height="18" /><img src="resim/smilies/confused.png" alt="" width="18" height="18" /><img src="resim/smilies/eek.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" /><img src="resim/smilies/geek.png" alt="" width="18" height="18" /><img src="resim/smilies/mad.png" alt="" width="18" height="18" /><img src="resim/smilies/laugh.png" alt="" width="18" height="18" /><img src="resim/smilies/inlove.png" alt="" width="18" height="18" /><img src="resim/smilies/redface.png" alt="" width="18" height="18" /><img src="resim/smilies/sleep.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsdown.png" alt="" width="18" height="18" /><img src="resim/smilies/whistling.png" alt="" width="18" height="18" /><img src="resim/smilies/wink.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsup.png" alt="" width="18" height="18" /><img src="resim/smilies/smile.png" alt="" width="18" height="18" /><img src="resim/smilies/sneaky.png" alt="" width="18" height="18" /><img src="resim/smilies/smile.png" alt="" width="18" height="18" /><img src="resim/smilies/roflmao.png" alt="" width="18" height="18" /><img src="resim/smilies/rolleyes.png" alt="" width="18" height="18" /><img src="resim/smilies/mad.png" alt="" width="18" height="18" /><img src="resim/smilies/laugh.png" alt="" width="18" height="18" /><img src="resim/smilies/inlove.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(137, '1', '5', '', '', '1347818923', 'admin', '18', '127.0.0.1', 'Re: Ýlk konu', 'tretretre r<img src="resim/smilies/inlove.png" alt="" width="18" height="18" /><img src="resim/smilies/laugh.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" /><img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" /><img src="resim/smilies/sleep.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(138, '7', '1', '', '', '1347845482', 'admin', '18', '127.0.0.1', 'Re: ewrewrew', '[QUOTE=admin] <img src="resim/smilies/cautious.png" alt="" width="18" height="18" /><img src="resim/smilies/coffee.png" alt="" width="18" height="18" /><img src="resim/smilies/confused.png" alt="" width="18" height="18" /><img src="resim/smilies/cool.png" alt="" width="18" height="18" /><img src="resim/smilies/frown.png" alt="" width="18" height="18" /><img src="resim/smilies/laugh.png" alt="" width="18" height="18" /><img src="resim/smilies/redface.png" alt="" width="18" height="18" /><img src="resim/smilies/sleep.png" alt="" width="18" height="18" /><img src="resim/smilies/sick.png" alt="" width="18" height="18" /><img src="resim/smilies/rolleyes.png" alt="" width="18" height="18" /><img src="resim/smilies/sneaky.png" alt="" width="18" height="18" /><img src="resim/smilies/tongue.png" alt="" width="18" height="18" /><img src="resim/smilies/x3.png" alt="" width="18" height="18" /><img src="resim/smilies/wink.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsup.png" alt="" width="18" height="18" /><img src="resim/smilies/smile.png" alt="" width="18" height="18" /><img src="resim/smilies/roflmao.png" alt="" width="18" height="18" /><img src="resim/smilies/mad.png" alt="" width="18" height="18" /><img src="resim/smilies/geek.png" alt="" width="18" height="18" />[/QUOTE]tretretre tretre tr', 'resim/icons/icon2.gif', '', '', '', '', ''),
(139, '9', '2', '', '', '1348859332', 'admin', '18', '127.0.0.1', 'Re: rewrewrewrewrew', '<img src="resim/smilies/O_o.png" alt="" width="18" height="18" /><img src="resim/smilies/coffee.png" alt="" width="18" height="18" /><img src="resim/smilies/devilish.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(140, '7', '1', '', '', '1349041657', 'admin', '18', '127.0.0.1', 'Re: ewrewrew', 'rttrt rtrt rtr', 'resim/icons/icon2.gif', '', '', '', '', ''),
(141, '26', '3', '', 'konu', '1349046614', 'trojen', '19', '127.0.0.1', 'TROJENDEN SELAM', 'TR RTR TRTR TR TRT R<img src="resim/smilies/eek.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(143, '16', '5', '', '', '1349047842', 'admin', '18', '127.0.0.1', 'Re: Duyuru olacak', '<img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/notworthy.png" alt="" width="18" height="18" /><img src="resim/smilies/sleep.png" alt="" width="18" height="18" /><img src="resim/smilies/sick.png" alt="" width="18" height="18" /><img src="resim/smilies/thumbsup.png" alt="" width="18" height="18" /><img src="resim/smilies/tongue.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(144, '9', '2', '', '', '1349048134', 'admin', '18', '127.0.0.1', 'Re: rewrewrewrewrew', '<img src="resim/smilies/giggle.png" alt="" width="18" height="18" /><img src="resim/smilies/devilish.png" alt="" width="18" height="18" /><img src="resim/smilies/coffee.png" alt="" width="18" height="18" />[QUOTE]tretretretre [/QUOTE]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(145, '9', '2', '', '', '1349048142', 'admin', '18', '127.0.0.1', 'Re: rewrewrewrewrew', '[CODE]tret retre [/CODE]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(146, '9', '2', '', '', '1349048152', 'admin', '18', '127.0.0.1', 'Re: rewrewrewrewrew', '[PHP]tretre tret re[/PHP]', 'resim/icons/icon1.gif', '', '', '', '', ''),
(147, '27', '5', '', 'konu', '1349213729', 'admin', '18', '127.0.0.1', 'Anket', 'anket', 'resim/icons/icon1.gif', '', '', '', '', ''),
(148, '28', '2', '', 'konu', '1349460003', 'admin', '18', '127.0.0.1', 'rrrrrrrr', 'rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr', 'resim/icons/icon1.gif', '', '', '', '', ''),
(149, '29', '1', '', 'konu', '1349572303', 'admin', '18', '127.0.0.1', 'rewrewrewrewrew', 'rewrewrew', 'resim/icons/icon1.gif', '', '', '', '', ''),
(150, '30', '1', '', 'konu', '1349572376', 'admin', '18', '127.0.0.1', 'yyyyyyyyyyyy', 'yyyyyyyyyyyyyyyyyyyyyyyyyy', 'resim/icons/icon1.gif', '', '', '', '', ''),
(151, '30', '1', '', '', '1349574058', 'admin', '18', '127.0.0.1', 'Re: yyyyyyyyyyyy', 'rewrewre', 'resim/icons/icon1.gif', '', '', '', '', ''),
(152, '7', '1', '', '', '1349782725', 'admin', '18', '127.0.0.1', 'Re: ewrewrew', 'rewrewrew', 'resim/icons/icon2.gif', '', '', '', '', ''),
(153, '31', '2', '1', 'konu', '1349785753', 'admin', '18', '127.0.0.1', 'Bu güzel olacak', 'rewrew rewrewr ewre wrew rewr e', 'resim/icons/icon12.gif', '', '', '', '', ''),
(154, '31', '2', '1', '', '1349785876', 'admin', '18', '127.0.0.1', 'Re: Bu güzel olacak', 'REWREWREW<img src="resim/smilies/redface.png" alt="" width="18" height="18" />', 'resim/icons/icon12.gif', '', '1353268439', 'admin', '18', '1'),
(155, '32', '2', '1', 'konu', '1349786184', 'admin', '18', '127.0.0.1', 'Züpper Anket', 'Evvet &ccedil;ok g&uuml;zel anket', 'resim/icons/icon13.gif', '', '', '', '', ''),
(157, '29', '1', '1', '', '1349789691', 'admin', '18', '127.0.0.1', 'Re: rewrewrewrewrew', '<img src="resim/smilies/barefoot.png" alt="" width="18" height="18" /><img src="resim/smilies/biggrin.png" alt="" width="18" height="18" /><img src="resim/smilies/cautious.png" alt="" width="18" height="18" /><img src="resim/smilies/cool.png" alt="" width="18" height="18" /><img src="resim/smilies/laugh.png" alt="" width="18" height="18" /><img src="resim/smilies/roflmao.png" alt="" width="18" height="18" /><img src="resim/smilies/sleep.png" alt="" width="18" height="18" />', 'resim/icons/icon1.gif', '', '', '', '', ''),
(158, '33', '4', '2', 'konu', '1353431666', 'admin', '18', '127.0.0.1', 'Sabit konu olacak', 'ew ewew ewe wew ewew ew ewew ew', 'resim/icons/icon3.gif', '', '', '', '', ''),
(159, '34', '8', '3', 'konu', '1353431980', 'admin', '18', '127.0.0.1', 'rerer er', 're re re rere', 'resim/icons/icon11.gif', '', '', '', '', ''),
(160, '33', '4', '2', '', '1353439670', 'admin', '18', '127.0.0.1', 'Re: Sabit konu olacak', 'rwerew', 'resim/icons/icon3.gif', '', '', '', '', ''),
(161, '34', '8', '3', '', '1353448398', 'admin', '18', '127.0.0.1', 'Re: rerer er', 'tretretre', 'resim/icons/icon11.gif', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `online_kullanicilar`
--

CREATE TABLE IF NOT EXISTS `online_kullanicilar` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `kul_id` int(50) NOT NULL,
  `kul_adi` varchar(100) NOT NULL,
  `kul_giris` varchar(255) NOT NULL,
  `kul_s_id` varchar(255) NOT NULL,
  `kul_son_sayfa` varchar(300) NOT NULL,
  `kul_son_sayfa_baslik` varchar(1000) NOT NULL,
  `kul_ip` varchar(200) NOT NULL,
  `kul_agent` varchar(1000) NOT NULL,
  `kul_son_aktivite` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=748 ;

--
-- Tablo döküm verisi `online_kullanicilar`
--

INSERT INTO `online_kullanicilar` (`id`, `kul_id`, `kul_adi`, `kul_giris`, `kul_s_id`, `kul_son_sayfa`, `kul_son_sayfa_baslik`, `kul_ip`, `kul_agent`, `kul_son_aktivite`) VALUES
(705, 0, 'misafir', '1349784166', 'k6oijj34hm9km4dblebta8nsk5', 'showthread.php?t=29', ' - rewrewrewrewrew', '127.0.0.1', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)', '1349784166'),
(709, 0, 'misafir', '1349806659', 'enujl1d8aae5gf102bcf63ng01', 'index.php', 'Anasayfa', '127.0.0.1', 'Mozilla/5.0 (Windows NT 5.1; rv:15.0) Gecko/20100101 Firefox/15.0.1', '1349806659'),
(740, 0, 'misafir', '1353268538', 'cg07rl5rjv525a1rks02vdn7b4', 'index.php', 'Anasayfa', '127.0.0.1', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)', '1353268538'),
(744, 0, 'misafir', '1353438630', 'ohtmskno9a9403c0tgdm4jo385', 'index.php', 'Anasayfa', '127.0.0.1', 'Mozilla/5.0 (Windows NT 5.1; rv:16.0) Gecko/20100101 Firefox/16.0', '1353438630');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ozel_mesaj`
--

CREATE TABLE IF NOT EXISTS `ozel_mesaj` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `kim_gonderdi` varchar(255) NOT NULL,
  `kim_gonderdi_id` varchar(255) NOT NULL,
  `kime_gonderdi` varchar(255) NOT NULL,
  `kime_gonderdi_id` varchar(255) NOT NULL,
  `mesaj_baslik` varchar(255) NOT NULL,
  `mesaj_ikon` varchar(255) NOT NULL,
  `mesaj_govde` varchar(5000) NOT NULL,
  `gonderme_zamani` varchar(255) NOT NULL,
  `okunma_zamani` varchar(255) NOT NULL,
  `gonderenin_kutusu` varchar(255) NOT NULL,
  `alanin_kutusu` varchar(255) NOT NULL,
  `gonderen_klasorID` varchar(255) NOT NULL,
  `alan_klasorID` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Tablo döküm verisi `ozel_mesaj`
--

INSERT INTO `ozel_mesaj` (`id`, `kim_gonderdi`, `kim_gonderdi_id`, `kime_gonderdi`, `kime_gonderdi_id`, `mesaj_baslik`, `mesaj_ikon`, `mesaj_govde`, `gonderme_zamani`, `okunma_zamani`, `gonderenin_kutusu`, `alanin_kutusu`, `gonderen_klasorID`, `alan_klasorID`, `ip`) VALUES
(1, 'trojen', '19', 'admin', '18', 'selam adminim bugün nasýlsýn', '', 'nasýlsýn? <img src="resim/smilies/redface.png" alt="" width="18" height="18" />', '1347250643', '1347846718', 'giden', '', '', '4', '127.0.0.1'),
(2, 'admin', '18', 'trojen', '19', 'Re: selam adminim bugün nasýlsýn', '', '[QUOTE]nasýlsýn? <img src="resim/smilies/redface.png" alt="" width="18" height="18" />[/QUOTE]eywallah kardeþim senden nbr <img src="resim/smilies/geek.png" alt="" width="18" height="18" /><img src="resim/smilies/mad.png" alt="" width="18" height="18" />', '1347251245', '1347251268', '', '', '4', '3', '127.0.0.1'),
(3, 'trojen', '19', 'admin', '18', 'rewrewre', '', 'rewrew rewrewrew', '1347251286', '1347251307', 'giden', '', '', '', '127.0.0.1'),
(4, 'aspendos', '32', 'admin', '18', 'selam', '', 'ben aspendos<img src="resim/smilies/inlove.png" alt="" width="18" height="18" />', '1347255428', '', 'giden', '', '', '', '127.0.0.1'),
(5, 'aspendos', '32', 'aspendos', '32', 'selam', '', 'ben aspendos<img src="resim/smilies/inlove.png" alt="" width="18" height="18" />', '1347255428', '1347360454', 'giden', 'gelen', '', '', '127.0.0.1'),
(6, 'aspendos', '32', 'trojen', '19', 'selam', '', 'ben aspendos<img src="resim/smilies/inlove.png" alt="" width="18" height="18" />', '1347255428', '1347293267', 'giden', 'gelen', '', '', '127.0.0.1'),
(7, 'aspendos', '32', 'ferrari', '21', 'selam', '', 'ben aspendos<img src="resim/smilies/inlove.png" alt="" width="18" height="18" />', '1347255428', '1347255471', 'giden', 'gelen', '', '', '127.0.0.1'),
(8, 'ferrari', '21', 'aspendos', '32', 'Re: selam', '', '[QUOTE]ben aspendos<img src="resim/smilies/inlove.png" alt="" width="18" height="18" />[/QUOTE]ben de ferrari', '1347255488', '1347360453', 'giden', 'gelen', '', '', '127.0.0.1'),
(9, 'ferrari', '21', 'admin', '18', 'Re: selam', '', '[QUOTE]ben aspendos<img src="resim/smilies/inlove.png" alt="" width="18" height="18" />[/QUOTE]ben de ferrari', '1347255488', '1347846586', 'giden', '', '', '4', '127.0.0.1'),
(10, 'trojen', '19', 'aspendos', '32', 'Re: selam', '', '[QUOTE]ben aspendos<img src="resim/smilies/inlove.png" alt="" width="18" height="18" />[/QUOTE]memnun oldum ben de trojen<img src="resim/smilies/notworthy.png" alt="" width="18" height="18" />', '1347293290', '1347360451', 'giden', 'gelen', '', '', '127.0.0.1'),
(11, 'admin', '18', 'admin', '18', 'ddddddddddd', '', 'ddddddddddddddddddddddd', '1349120431', '1349120454', '', '', '4', '4', '127.0.0.1'),
(12, 'admin', '18', 'admin', '18', 'dddddddddddd', 'resim/icons/icon14.gif', 'ddddddddddddddd', '1349214645', '1353443609', '', '', '2', '', '127.0.0.1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ozel_mesaj_klasor`
--

CREATE TABLE IF NOT EXISTS `ozel_mesaj_klasor` (
  `klasorID` int(255) NOT NULL AUTO_INCREMENT,
  `kul_ID` varchar(255) NOT NULL,
  `icerdigi_mesaj_say` varchar(255) NOT NULL,
  `klasor_adi` varchar(255) NOT NULL,
  `klasor_resim` varchar(255) NOT NULL,
  PRIMARY KEY (`klasorID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Tablo döküm verisi `ozel_mesaj_klasor`
--

INSERT INTO `ozel_mesaj_klasor` (`klasorID`, `kul_ID`, `icerdigi_mesaj_say`, `klasor_adi`, `klasor_resim`) VALUES
(1, '19', '0', 'Beyaz klasörüm', 'beyaz.png'),
(2, '18', '1', 'Yeþil Klasörüm', 'yesil.png'),
(3, '19', '1', 'Kýrmýzý klasörüm', 'kirmizi.png'),
(4, '18', '4', 'Sarý klasör', 'sari.png'),
(6, '18', '0', 'Beyaz Klasör', 'beyaz.png');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `rating_konu`
--

CREATE TABLE IF NOT EXISTS `rating_konu` (
  `rating_id` int(255) NOT NULL AUTO_INCREMENT,
  `rating_konu_id` varchar(255) NOT NULL,
  `rating_kul_id` varchar(255) NOT NULL,
  `rating_degeri` varchar(255) NOT NULL,
  `rating_kul_ip` varchar(255) NOT NULL,
  `rating_zamani` varchar(255) NOT NULL,
  PRIMARY KEY (`rating_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=56 ;

--
-- Tablo döküm verisi `rating_konu`
--

INSERT INTO `rating_konu` (`rating_id`, `rating_konu_id`, `rating_kul_id`, `rating_degeri`, `rating_kul_ip`, `rating_zamani`) VALUES
(1, '21', '18', '10', '127.0.0.1', '1345265703'),
(2, '35', '18', '0', '127.0.0.1', '1345267505'),
(3, '35', '20', '9', '127.0.0.1', '1345269505'),
(4, '35', '19', '7', '127.0.0.1', '1345268527'),
(5, '34', '18', '10', '127.0.0.1', '1345269550'),
(6, '34', '19', '0', '127.0.0.1', '1345269582'),
(7, '33', '18', '2', '127.0.0.1', '1345269804'),
(8, '33', '19', '3', '127.0.0.1', '1345269838'),
(9, '35', '1', '10', '127.0.0.1', '1345270238'),
(10, '32', '18', '10', '127.0.0.1', '1345270549'),
(11, '31', '18', '8', '127.0.0.1', '1345271875'),
(12, '36', '18', '8', '127.0.0.1', '1345272105'),
(13, '36', '1', '0', '127.0.0.1', '1345272789'),
(14, '18', '1', '6', '127.0.0.1', '1345272824'),
(15, '34', '1', '0', '127.0.0.1', '1345273239'),
(16, '28', '18', '8', '127.0.0.1', '1345277402'),
(17, '28', '1', '0', '127.0.0.1', '1345277440'),
(18, '29', '1', '0', '127.0.0.1', '1345277529'),
(19, '32', '19', '6', '127.0.0.1', '1345328367'),
(20, '22', '18', '8', '127.0.0.1', '1345383250'),
(21, '52', '18', '9', '127.0.0.1', '1345481562'),
(22, '55', '19', '10', '127.0.0.1', '1345492674'),
(23, '64', '21', '7', '127.0.0.1', '1345564549'),
(24, '64', '18', '0', '127.0.0.1', '1345564564'),
(25, '64', '19', '7', '127.0.0.1', '1345574030'),
(26, '66', '1', '7', '127.0.0.1', '1345577701'),
(27, '66', '19', '7', '127.0.0.1', '1345751100'),
(28, '63', '18', '7', '127.0.0.1', '1345843342'),
(29, '19', '18', '0', '127.0.0.1', '1345843384'),
(30, '70', '18', '8', '127.0.0.1', '1345850483'),
(31, '67', '18', '7', '127.0.0.1', '1346228050'),
(32, '4', '18', '8', '127.0.0.1', '1346237152'),
(33, '7', '18', '6', '127.0.0.1', '1346365681'),
(34, '1', '18', '6', '127.0.0.1', '1346394614'),
(35, '10', '18', '5', '127.0.0.1', '1346399700'),
(36, '9', '18', '5', '127.0.0.1', '1346503920'),
(37, '5', '18', '8', '127.0.0.1', '1346504323'),
(38, '3', '18', '8', '127.0.0.1', '1346536137'),
(39, '15', '18', '5', '127.0.0.1', '1346537760'),
(40, '2', '18', '6', '127.0.0.1', '1346583247'),
(41, '13', '18', '10', '127.0.0.1', '1347139502'),
(42, '16', '18', '5', '127.0.0.1', '1347145452'),
(43, '13', '19', '0', '127.0.0.1', '1347215495'),
(44, '18', '19', '6', '127.0.0.1', '1347218205'),
(45, '18', '18', '0', '127.0.0.1', '1347218464'),
(46, '20', '18', '7', '127.0.0.1', '1347218768'),
(47, '17', '19', '8', '127.0.0.1', '1347218961'),
(48, '8', '18', '5', '127.0.0.1', '1347250219'),
(49, '21', '32', '0', '127.0.0.1', '1347255537'),
(50, '25', '18', '3', '127.0.0.1', '1347321366'),
(51, '24', '18', '5', '127.0.0.1', '1347323769'),
(52, '17', '18', '3', '127.0.0.1', '1348150331'),
(53, '27', '18', '5', '127.0.0.1', '1349213777'),
(54, '29', '18', '10', '127.0.0.1', '1349634899'),
(55, '23', '18', '6', '127.0.0.1', '1349806702');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yapilan_aramalar`
--

CREATE TABLE IF NOT EXISTS `yapilan_aramalar` (
  `arama_id` int(255) NOT NULL AUTO_INCREMENT,
  `aranan_kelime` varchar(255) NOT NULL,
  `aranan_kullanici` varchar(255) NOT NULL,
  `kim_aradi` varchar(255) NOT NULL,
  `kim_aradi_ip` varchar(255) NOT NULL,
  `nerede_aradi` varchar(255) NOT NULL,
  `sonuc_nasil_goster` varchar(255) NOT NULL,
  `sonuc_sort` varchar(100) NOT NULL,
  `arama_zamani` varchar(255) NOT NULL,
  PRIMARY KEY (`arama_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Tablo döküm verisi `yapilan_aramalar`
--

INSERT INTO `yapilan_aramalar` (`arama_id`, `aranan_kelime`, `aranan_kullanici`, `kim_aradi`, `kim_aradi_ip`, `nerede_aradi`, `sonuc_nasil_goster`, `sonuc_sort`, `arama_zamani`) VALUES
(1, 'nbr', '', '18', '127.0.0.1', 'tum_forumlar', 'mesajlarda', 'DESC', '1349214536'),
(2, '', 'trojen', '18', '127.0.0.1', 'tum_forumlar', 'mesajlarda', 'DESC', '1349548365'),
(3, 'anket', '', '18', '127.0.0.1', 'tum_forumlar', 'mesajlarda', 'DESC', '1353431808');
